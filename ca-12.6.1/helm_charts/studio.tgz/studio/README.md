# STUDIO

This is the Helm chart for the Studio

## Prerequisites

- Docker with Kubernetes enabled
- HELM Cli

## Installing the chart
- Add our ASG Helm repository (use your Artifactory user and token):
  ```
  helm repo add rocket https://wal-artifactory.rocketsoftware.com/artifactory/mobf-helm-virtual-wal/ --username *** --password ***
  ```
- Check if studio chart is available:
  ```
  helm search studio
  ```
  The output should be like:
  ```
  NAME                         CHART VERSION    APP VERSION         DESCRIPTION                
  rocket/studio                 4.0.0            4.0.0              Studio Helm chart for Kubernetes
  ```
- You can inspect the chart with:
  ```
  helm inspect releasename rocket/studio --version 4.0.0
  ```

## Uninstalling the Chart

To uninstall/delete the `my-release` deployment:

```console
$ helm delete my-release
```

## Configuration

You can specify each property using the `--set key=value[,key=value]` argument to `helm install`.
Alternatively, a YAML file that specifies the values for the above parameters can be provided while installing the chart. For example,
For connecting to an external database, update the datasource.* configuration on your values.yaml and execute the below script.  

```
$ helm install rocket/studio --name my-release -f values.yaml
```
OR
```
$ helm install rocket/studio --name my-release --set spring.datasource.url=jdbc:postgresql://localhost:5432/roca
```


The following table lists the configurable parameters of the Studio chart and their default values.

| Parameter | Description | Default                                                                                                                                                                        |
|--|--|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `image.repository` | Specify image docker registry and the name of the image	 | `studio`                                                                                                                                                                       |
| `image.tag` | Container image version | `12.6.1-SNAPSHOT`                                                                                                                                                              |
| `image.pullPolicy` | Container image pull policy | `IfNotPresent`                                                                                                                                                                 |
| `imagePullSecrets` | Image Secrets to be created in the local environment to pull the docker images | `dockerlocal`                                                                                                                                                                  |
| `nameOverride` | nameOverride is the name of the service to publish with | ``                                                                                                                                                                             
| `fullnameOverride` | fullnameOverride is the name of the service to publish with | ``                                                                                                                                                                             
| `service.type` | Studio Service Type | `ClusterIP`                                                                                                                                                                    |
| `service.port` | Studio Service Port | `8082`                                                                                                                                                                         |
| `service.targetPort` | Studio Target Port | `8082`                                                                                                                                                                         |
| `resources` | CPU/Memory resource requests/limits	 | `default`                                                                                                                                                                      |
| `nodeSelector` | Node labels for pod assignment | `{}`                                                                                                                                                                           |
| `tolerations` | Toleration labels for pod assignment	| `default`                                                                                                                                                                      |
| `affinity` | Affinity settings for pod assignment | `{}`                                                                                                                                                                           |
| `replicaCount` | Deployment replicas of the POD | `1`                                                                                                                                                                            |
| `spring.datasource.url` | JDBC  Database path with port no and databasename	| `jdbc:postgresql://<IP_ADDRESS>:<PORT>/<DATABASE_NAME>`                                                                                                                        |
| `spring.datasource.username` | JDBC  Database username	| `postgres`                                                                                                                                                                     |
| `spring.datasource.password` | JDBC  Database password	| `postgres`                                                                                                                                                                     |
| `spring.datasource.password` | JDBC  Driver class Name password	| `org.postgresql.Driver`                                                                                                                                                        |
| `spring.datasource.jpa.databasePlatform` | JDBC Hikari connectionTimeout | `org.hibernate.dialect.PostgreSQL9Dialect`                                                                                                                                     |
| `spring.datasource.jpa.hibername.ddlAuto` | Auto comit status of JPA | `none`                                                                                                                                                                         |
| `cloud.discovery.client.simple.instances.authorization.uri` | URI for Authorization service | ` http://<IP_ADDRESS>:<PORT>/mobius`                                                                                                                                           |
| `servlet.multipart.enabled` | Enable multipart | `true`                                                                                                                                                                         |
| `persistence.volumeName` | Persistence volume name and need not be updated | `web-wcr`                                                                                                                                                                      |
| `persistence.claimName` | Provide an existing Persistent Volume Claim, the value is evaluated as a template. | `studio-efs`                                                                                                                                                                   |
| `persistence.accessMode` | Persistence Volume Claim Access Mode for Studio volume | `ReadWriteMany`                                                                                                                                                                |
| `persistence.size` | Persistence Volume Claim Storage Request for Studio volume | `1Mi`                                                                                                                                                                          |
| `persistence.hostPath` | Host Path for persistence	 | `/wcr`                                                                                                                                                                         |
| `persistence.containerPath` | Container path for persistence	 | `/app/Web`                                                                                                                                                                     |
| `persistence.storageClass` | Storage Class for persistence | `efs`                                                                                                                                                                          |
| `AdditionalVolumeMounts` | Used for mounting Additional Volumes | 3 Mounts are available by default                                                                                                                                              |
| `AdditionalVolumeMounts.name` | AdditionalVolumeMounts Name | `studio-data`                                                                                                                                                                  |
| `AdditionalVolumeMounts.mountPath` | Mount path for AdditionalVolumeMounts | `/home/asg/Web`                                                                                                                                                                |
| `AdditionalVolumeMounts.subPath` | Sub path for AdditionalVolumeMounts | `Web`                                                                                                                                                                          |
| `AdditionalVolumes` | Additional Volumes for Studio   | ``                                                                                                                                                                             |
| `AdditionalVolumes.name` | Additional Volumes Name | `studio-data`                                                                                                                                                                  |
| `AdditionalVolumes.persistentVolumeClaim.claiName` | Claim name for Persistent Volume | `studio-efs`                                                                                                                                                                   |
| `ports.name` | Name of the port | `http`                                                                                                                                                                         |
| `ports.containerPort` | ContainerPort is the port where container should run | `8082`                                                                                                                                                                         |
| `ports.targetPort` | TargetPort is the port where the service points to | `8082`                                                                                                                                                                         |
| `ports.protocol` | Name of the protocol | `TCP`                                                                                                                                                                          |
| `livenessProbe.*` | Container liveness values for Studio | `*`                                                                                                                                                                            |
| `readinessProbe.*` | Container readiness values for Studio | `*`                                                                                                                                                                            |
| `server.port` | Port for Server | `8082`                                                                                                                                                                         |
| `server.ssl.enabled` | Used for enabling SSL Configuration | `false`                                                                                                                                                                        |
| `server.ssl.protocol` | Protocol for enabling SSL Configuration | `TLS`                                                                                                                                                                          |
| `server.ssl.enabledProtocols` | Enabled  protocol for  SSL Configuration | `false`                                                                                                                                                                        |
| `server.ssl.keyStore` | Trust Store file path | `classpath:support-files/pfx-store/key_store.pfx`                                                                                                                              |
| `server.ssl.keyStorePassword` | Trust Store file password | `password`                                                                                                                                                                     |
| `server.ssl.trustStore` | Trust Store file path | `classpath:support-files/pfx-store/trust_store.pfx`                                                                                                                            |
| `server.ssl.trustStorePassword` | Trust Store file password | `password`                                                                                                                                                                     |
| `server.ssl.keystoreType` | Keystore Type | `PKCS12`                                                                                                                                                                       |
| `studio.authorization.enabled` | Enable Authorization | `false`                                                                                                                                                                        |
| `studio.service.dsPoolSize` | DS Pool Size value | `10`                                                                                                                                                                           |
| `studio.service.location` | Studio Location | `/home/asg/Studio_Workspace`                                                                                                                                                   |
| `studio.service.workspaceName` | Workspace Name | `Workspace`                                                                                                                                                                    |
| `studio.service.angularWorkspace` | Angular Workspace Path | `/home/asg/Studio_Workspace/Workspace/default_user/angular-workspace`                                                                                                          |
| `studio.service.encryptionKey` | Encryption Key | `RocketEncryption`                                                                                                                                                             |
| `studio.service.aiServiceUrl` | AI Service URL | `http://<IP_ADDRESS>:<PORT>/api`                                                                                                                                               |
| `studio.service.validProjectFolders` | Valid Project Folders | `UI Models,App Roles,Datasources,Process Models`                                                                                                                               |
| `studio.service.syncTreeExcludeFolders` | Folders names to exclude while syncing | `node_modules,.git,metaData`                                                                                                                                                   |
| `studio.service.openProjectExcludeFolder` | Folders names to exclude | `angular-Workspace,metaData,App Packages,.git,.svn`                                                                                                                            |
| `studio.service.scmIgnoreFileName` | File extensions for ignoring in svn | `.svn`                                                                                                                                                                         |
| `studio.service.processEngineUrl` | Process Engine URL | `http://<IP_ADDRESS>:<PORT>/flowable-rest`                                                                                                                                     |
| `studio.service.mobiusResourcesUrl` | Mobius Resources URL | `http://<IP_ADDRESS>:<PORT>/mobius/rest/resources`                                                                                                                             |
| `studio.service.enableAi` | Enable AI for Studio | `false`                                                                                                                                                                        |
| `studio.service.npmModules` | NPM Modules value required | `caniuse-lite, jexcel`                                                                                                                                                         |
| `studio.service.runningProperties.mode` | Studio runningProperties Mode | `studio`                                                                                                                                                                       |
| `studio.service.runningProperties.authorized_permissions` | Studio runningProperties Authorized Permission | `DeveloperAccess`                                                                                                                                                              |
| `studio.service.runningProperties.authorized_scopes` | Studio runningProperties Authorized scope | `authorization.fullaccess`                                                                                                                                                     |
| `studio.service.runningProperties.httptimeout` | Studio runningProperties HttpTimeout value | `3000`                                                                                                                                                                         |
| `asg.security.enabled` | Enable security features, recommended to be enabled | `true`                                                                                                                                                                         |
| `asg.security.urlPatterns` | Enable security features on the URL pattern | `/rest/*`                                                                                                                                                                      |
| `asg.security.basicauth.inbound` | Inbound for Basic Auth, not recommended for Production. Set to false on Production | `true`                                                                                                                                                                         |
| `asg.security.basicauth.username` | Username for basic auth | `admin`                                                                                                                                                                        |
| `asg.security.basicauth.password` | Password for basic auth | `admin`                                                                                                                                                                        |
| `asg.security.basicauth.groups` | Groups required for basic auth | `StudioAdmin,StudioUser`                                                                                                                                                       |
| `asg.security.appServer.enabled` | App Server security with Proxy | `false`                                                                                                                                                                        |
| `asg.security.appServer.type` | App Server Type | `CUSTOM`                                                                                                                                                                       |
| `asg.security.appServer.attributes.userName` | User name for App Server | `X-Remote-User`                                                                                                                                                                |
| `asg.security.appServer.attributes.groupNames` | Group name for App Server | `groups`                                                                                                                                                                       |
| `asg.security.appServer.attributes.groupSeparator` | Group Separator for App Server | `,`                                                                                                                                                                            |
| `asg.security.jwt.enabled` | Internal JWT | `false`                                                                                                                                                                        |
| `asg.security.jwt.serviceTokenSettings.urlPatterns` | URL Pattern for JWT | `/*`                                                                                                                                                                           |
| `asg.security.jwt.serviceTokenSettings.privateKey` | JWT Private Key | `<private Key>`                                                                                                                                                                |
| `asg.security.jwt.serviceTokenSettings.publicKey` | JWT Public Key | `<public Key>`                                                                                                                                                                 |
| `asg.security.jwt.serviceTokenSettings.expireSeconds` | Expiration for JWT | `36000`                                                                                                                                                                        |
| `asg.security.openidConnectTwo.enabled` | Enables the OpenidConnectTwo filter | `false`                                                                                                                                                                        |
| `asg.security.openidConnectTwo.outbound.` | Determines if the JWT should be passed downstream or not. | `true`                                                                                                                                                                         |
| `asg.security.openidConnectTwo.validate.` | Enables JWT's identity token signature validation | `true`                                                                                                                                                                         |
| `asg.security.openidConnectTwo.iamGroups.` | Determines if the groups should be retrieved the Identity Access Manager | `false`                                                                                                                                                                        |
| `asg.security.openidConnectTwo.whitelistIssuers.` | If there is a whitelist, then issuer, within the JWT must be in the list. If there is no entries in the whitelist, then nothing is allowed. If you put an asterisk, then any JWT is allowed, if valid. | `https://<HOST>:<PORT>/auth/realms/*`                                                                                                                                          |
| `asg.security.openidConnectTwo.mapping.userName` | Reads the configured username in case of access token | `preferred_username`                                                                                                                                                           |
| `asg.security.openidConnectTwo.mapping.groups` | Groups to be mapped for OpenidConnectTwo | `groups`                                                                                                                                                                       |
| `asg.security.iam.ldap.enabled` | Enable Identity and Access Managers with ldap type | `false`                                                                                                                                                                        |
| `asg.security.iam.ldap.server` | Server URL for ldap | `abc.com`                                                                                                                                                                      |
| `asg.security.iam.ldap.port` | Server port  for ldap | `389`                                                                                                                                                                          |
| `asg.security.iam.ldap.user` | User details for ldap | `CN=TEST,OU=Testing Accounts,OU=User Accounts,DC=asg,DC=com`                                                                                                                   |
| `asg.security.iam.ldap.password` | Password for ldap | `TEST`                                                                                                                                                                         |
| `asg.security.iam.ldap.groupDN` | groupDN for ldap | `DC=abc,DC=com`                                                                                                                                                                |
| `asg.security.iam.ldap.userDN` | userDN for ldap | `OU=User Accounts,DC=abc,DC=com`                                                                                                                                               |
| `asg.security.iam.ldap.userAttributes` | LDAP user attributes | `cn,memberof,proxyAddresses,textEncodedORAddress,mail`                                                                                                                         |
| `asg.security.iam.ldap.searchType` | Search type allowed | `CONTAINS`                                                                                                                                                                     |
| `asg.authorization.enabled` | Enable Authorization | `false`                                                                                                                                                                        |
| `logging.file` | File details for the logs generation | ``                                                                                                                                                                             |
| `logging.file.path` | File path in the local machine where logs can be generated | `${user.home}/asg/${spring.application.name}/logs`                                                                                                                             |
| `logging.file.name` | File name in the local machine where logs can be generated | `${user.home}/asg/${spring.application.name}/logs`                                                                                                                             |
| `logging.pattern` | Log pattern for the logs generation | ``                                                                                                                                                                             |
| `logging.pattern.file` | Patterns to be followed in log files | `%d{yyyy-MM-dd HH:mm:ss.SSS} %highlight{[%-5level]} %X{CORRELATION_ID} %X{TENANT}:%X{USER} %X{SERVICE} %style{[%t]}{magenta} %style{%c:%M}{cyan} - %replace{%msg}{[\r\n]}{}%n' |
| `logging.pattern.console` | Patterns to be followed in the console | `%d{yyyy-MM-dd HH:mm:ss.SSS} [%-5level] %X{CORRELATION_ID} %X{TENANT}:%X{USER} [%t] %c:%M - %replace{%msg}{[\r\n]}{}%n`                                                        |
| `logging.level.root` | Log level for the Spring framework logs | `INFO`                                                                                                                                                                         |
| `logging.level.com.asg.services` | Log level for CA Services | `ERROR`                                                                                                                                                                        |
| `logging.level.com.asg.common.authwrapper` | Log level for CA authwrapper | `ERROR`                                                                                                                                                                        |
| `logging.level.com.bpm.core` | Log level for CA bpm core | `ERROR`                                                                                                                                                                        |