# PROCESS ENGINE

This is the Helm chart for the Process Engine

## Prerequisites

- Docker with Kubernetes enabled
- HELM Cli

## Installing the chart
- Add our ASG Helm repository (use your Artifactory user and token):
  ```
  helm repo add rocket https://wal-artifactory.rocketsoftware.com/artifactory/mobf-helm-virtual-wal/ --username *** --password ***
  ```
- Check if ProcessEngine chart is available:
  ```
  helm search ProcessEngine
  ```
  The output should be like:
  ```
  NAME                         CHART VERSION    APP VERSION         DESCRIPTION                
  rocket/processengine     4.0.0            4.0.0               Process Engine Helm chart for Kubernetes
  ```
- You can inspect the chart with:
  ```
  helm inspect releasename rocket/processengine --version 4.0.0
  ```

## Uninstalling the Chart

To uninstall/delete the `my-release` deployment:

```console
$ helm delete my-release
```

## Configuration

You can specify each property using the `--set key=value[,key=value]` argument to `helm install`.
Alternatively, a YAML file that specifies the values for the above parameters can be provided while installing the chart. For example,
For connecting to an external database, update the datasource.* configuration on your values.yaml and execute the below script.  

```
$ helm install rocket/processengine --name my-release -f values.yaml
```
OR
```
$ helm install rocket/processengine --name my-release --set spring.datasource.url=jdbc:postgresql://localhost:5432/roca
```


The following table lists the configurable parameters of the Process Engine chart and their default values.

| Parameter | Description | Default                                                                                                                                                                        |
|--|--|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `image.repository` | Specify image docker registry and the name of the image	 | `processengine`                                                                                                                                                                |
| `image.tag` | Container image version | `12.6.1-SNAPSHOT-one`                                                                                                                                                              |
| `image.pullPolicy` | Container image pull policy | `IfNotPresent`                                                                                                                                                                 |
| `imagePullSecrets` | Image Secrets to be created in the local environment to pull the docker images | `dockerlocal`                                                                                                                                                                  |
| `nameOverride` | nameOverride is the name of the service to publish with | ``                                                                                                                                                                             
| `fullnameOverride` | fullnameOverride is the name of the service to publish with | ``                                                                                                                                                                             
| `service.type` | ProcessEngine Service Type | `ClusterIP`                                                                                                                                                                    |
| `service.port` | ProcessEngine Service Port | `8522`                                                                                                                                                                         |
| `service.targetPort` | ProcessEngine Target Port | `8522`                                                                                                                                                                         |
| `livenessProbe.*` | Container liveness values | `*`                                                                                                                                                                            |
| `readinessProbe.*` | Container readiness values | `*`                                                                                                                                                                            |
| `resources` | CPU/Memory resource requests/limits	 | `default`                                                                                                                                                                      |
| `nodeSelector` | Node labels for pod assignment | `{}`                                                                                                                                                                           |
| `tolerations` | Toleration labels for pod assignment	| `default`                                                                                                                                                                      |
| `affinity` | Affinity settings for pod assignment | `{}`                                                                                                                                                                           |
| `replicaCount` | Deployment replicas of the POD | `1`                                                                                                                                                                            |
| `spring.datasource.flowable.url` | JDBC Flowable Database path with port no and databasename	| `jdbc:postgresql://<IP_ADDRESS>:<PORT>/process_engine_flowable`                                                                                                                |
| `spring.datasource.flowable.username` | JDBC Flowable Database username	| `postgres`                                                                                                                                                                     |
| `spring.datasource.flowable.password` | JDBC Flowable Database password	| `postgres`                                                                                                                                                                     |
| `spring.datasource.root.url` | JDBC Root Database path with port no and databasename	| `jdbc:postgresql://<IP_ADDRESS>:<PORT>/process_engine_root`                                                                                                                    |
| `spring.datasource.root.username` | JDBC Root Database username	| `postgres`                                                                                                                                                                     |
| `spring.datasource.root.password` | JDBC Root Database password	| `postgres`                                                                                                                                                                     |
| `spring.datasource.root.hibernate.hbm2ddl.auto` | JDBC Hibernate DDL | `none`                                                                                                                                                                         |
| `spring.datasource.hikari.connectionTimeout` | JDBC Hikari connectionTimeout | `30000`                                                                                                                                                                        |
| `spring.datasource.hikari.minimumIdle` | JDBC Hikari minimumIdle | `50`                                                                                                                                                                           |
| `spring.datasource.hikari.maximumPoolSize` | JDBC Hikari maximumPoolSize | `50`                                                                                                                                                                           |
| `spring.datasource.hikari.idleTimeout` | JDBC Hikari idleTimeout | `10000`                                                                                                                                                                        |
| `spring.datasource.hikari.maxLifetime` | JDBC Hikari maxLifetime | `1000`                                                                                                                                                                         |
| `spring.datasource.hikari.autoCommit` | JDBC Hikari autoCommit | `true`                                                                                                                                                                         |
| `spring.jpa.hibername.ddlAuto` | Auto comit status of JPA | `none`                                                                                                                                                                         |
| `spring.h2.console.enabled` | Auto comit status of JPA | `none`                                                                                                                                                                         |
| `ports.name` | Name of the port | `http`                                                                                                                                                                         |
| `ports.containerPort` | ContainerPort is the port where container should run | `8522`                                                                                                                                                                         |
| `ports.targetPort` | TargetPort is the port where the service points to | `8522`                                                                                                                                                                         |
| `ports.protocol` | Name of the protocol | `TCP`                                                                                                                                                                          |
| `spring.initContainers.name.image` | Postgres container required for Process Engine to initialize | `docker.io/bitnami/postgresql:14.5.0`                                                                                                                                          |
| `spring.initContainers.env` | Env values for the Postgres container name:value  | `PGPASSWORD:postgres`                                                                                                                                                          |
| `spring.initContainers.env` | Env values for the Postgres container name:value  | `PGHOST:postgresql.shared`                                                                                                                                                     |
| `spring.initContainers.env` | Env values for the Postgres container name:value  | `PGUSER:postgres`                                                                                                                                                              |
| `spring.initContainers.env` | Env values for the Postgres container name:value  | `PGDATABASE:zenith_asg_process_engine`                                                                                                                                         |
| `cloud.discovery.client.simple.instances.authorization.uri` | URI for Authorization service | ` http://<IP_ADDRESS>:<PORT>/mobius`                                                                                                                                           |
| `server.ssl.enabled` | Used for enabling SSL Configuration | `false`                                                                                                                                                                        |
| `server.ssl.trustStore` | Trust Store file path | `classpath:trust_ssl.pfxx`                                                                                                                                                     |
| `server.ssl.trustStorePassword` | Trust Store file password | `password`                                                                                                                                                                     |
| `server.ssl.keystoreType` | Keystore Type | `PKCS12`                                                                                                                                                                       |
| `clientCertIgnore` | Ignore Client Certificate | `true`                                                                                                                                                                         |
| `flyway.enabled` | Flyway for Process Engine | `true`                                                                                                                                                                         |
! `flowable.http.connectionTimeout` | Flowable Connection Timeout | `5000`                                                                                                                                                                         |
! `flowable.http.connectionRequestTimeout` | Flowable ConnectionRequest Timeout | `10000`                                                                                                                                                                        |
! `flowable.http.socketTimeout` | Flowable Socket Timeout | `20000`                                                                                                                                                                        |
! `flowable.enableHistoryCleaning` | Flowable Connection Timeout | `false`                                                                                                                                                                        |
! `flowable.historyCleaningCycle` | Flowable historyCleaningCycle | `0 0 1 * * ?`                                                                                                                                                                  |
! `flowable.historyCleaningAfter` | Flowable historyCleaningAfter | `P365D`                                                                                                                                                                        |
! `flowable.historyCleaningBatchSize` | Flowable historyCleaningBatchSize | `100`                                                                                                                                                                          |
| `flowable.mail.server.host` | Flowable mail server host | `<HOST>`                                                                                                                                                                       |
| `flowable.mail.server.port` | Flowable mail server port | `25`                                                                                                                                                                           |
| `flowable.mail.server.useSsl` | Config for enabling SSL in flowable | `false`                                                                                                                                                                        |
| `flowable.mail.server.sslPort` | Flowable mail server sslPort | `465`                                                                                                                                                                          |
| `flowable.mail.server.defaultFrom` | Flowable mail server defaultFrom | `<FROM_EMAIL_ID>`                                                                                                                                                              |
| `flowable.mail.server.username` | Flowable mail server username | `<PROCESS_MAIL_SERVER_USERNAME>`                                                                                                                                               |
| `flowable.mail.server.password` | Flowable mail server password | `<PROCESS_MAIL_SERVER_PASSWORD>`                                                                                                                                               |
| `asg.processengine.awsAccessKey` | Process Engine awsAccessKey Configuration | `AKIAXX36BUQXXXXXEZNR`                                                                                                                                                         |
| `asg.processengine.awsSecretKey` | Process Engine awsSecretKey Configuration | `-`                                                                                                                                                                            |
| `asg.processengine.awsRegion` | Process Engine awsRegion Configuration | `us-east-1`                                                                                                                                                                    |
| `asg.processengine.awsS3BucketInput` | Process Engine awsS3BucketInput Configuration | `s3://`                                                                                                                                                                        |
| `asg.processengine.awsS3BucketOutput` | Process Engine awsS3BucketOutput Configuration | `s3://`                                                                                                                                                                        |
| `asg.processengine.awsSqsArn` | Process Engine awsSqsArn Configuration | `arn:abcd`                                                                                                                                                                     |
| `asg.processengine.awsSqsRole` | Process Engine awsSqsRole Configuration | `dev`                                                                                                                                                                          |
| `asg.processengine.awsComprehendRole` | Process awsComprehendRole Engine Configuration | `testcomprrole`                                                                                                                                                                |
| `asg.processengine.awsClientRetryDelayInSec` | Process Engine awsClientRetryDelayInSec Configuration | `120`                                                                                                                                                                          |
| `asg.processengine.awsClientRetryCount` | Process Engine awsClientRetryCount Configuration | `30`                                                                                                                                                                           |
| `asg.processengine.httpMaxTotalConnections` | Process Engine httpMaxTotalConnections Configuration | `50`                                                                                                                                                                           |
| `asg.processengine.httpDefaultConnMaxPerRoute` | Process Engine httpDefaultConnMaxPerRoute Configuration | `30`                                                                                                                                                                           |
| `asg.processengine.HttpIdelConnWaitTimeBeforeClassInSec` | Process Engine HttpIdelConnWaitTimeBeforeClassInSec Configuration | `30`                                                                                                                                                                           |
| `asg.processengine.HttpConnKeepAliveTimeInSec` | Process Engine HttpConnKeepAliveTimeInSec Configuration | `5`                                                                                                                                                                            |
| `asg.processengine.asyncExecutorMaxPoolSize` | Process Engine asyncExecutorMaxPoolSize Configuration | `100`                                                                                                                                                                          |
| `asg.processengine.asyncExecutorCorePoolSize` | Process Engine asyncExecutorCorePoolSize Configuration | `100`                                                                                                                                                                          |
| `asg.processengine.asyncExecutorThreadQueueSize` | Process Engine asyncExecutorThreadQueueSize Configuration | `1500`                                                                                                                                                                         |
| `asg.processengine.mailConnectTimeout` | Process Engine Configuration | `30000`                                                                                                                                                                        |
| `asg.processengine.mailSocketTimeout` | Process Engine Configuration | `30000`                                                                                                                                                                        |
| `asg.processengine.studioServiceUrl` | Studio  ServiceUrl | `http://<IP_ADDRESS>:<PORT>/rest/decisiontable/dummycontext/dummyapp/`                                                                                                         |
| `asg.processengine.contentautomationServiceUrl` | Content Automation ServiceUrl | `http://<HOST>:<PORT>/appmanager`                                                                                                                                              |
| `asg.processengine.authorizationServiceHost` | Authorizatoin Service Host | `http://<HOST>:<PORT>/mobius/rest/authorization`                                                                                                                               |
| `asg.processengine.mobiusResourcesUrl` | Mobius Resources Url | `http://<IP_ADDRESS>:<PORT>/mobius/rest/resources`                                                                                                                             |
| `asg.processengine.mobiusConnectorVersion` | Mobius Connector Version | `12.0`                                                                                                                                                                         |
| `asg.security.enabled` | Enable security features, recommended to be enabled | `true`                                                                                                                                                                         |
| `asg.security.urlPatterns` | Enable security features on the URL pattern | `/rest/*`                                                                                                                                                                      |
| `asg.security.basicauth.inbound` | Inbound for Basic Auth, not recommended for Production. Set to false on Production | `true`                                                                                                                                                                         |
| `asg.security.basicauth.username` | Username for basic auth | `admin`                                                                                                                                                                        |
| `asg.security.basicauth.password` | Password for basic auth | `admin`                                                                                                                                                                        |
| `asg.security.basicauth.groups` | Groups required for basic auth | `ContentAutomationUser,ContentAutomationAdmin`                                                                                                                                 |
| `asg.security.appServer.enabled` | App Server security with Proxy | `false`                                                                                                                                                                        |
| `asg.security.appServer.type` | App Server Type | `CUSTOM`                                                                                                                                                                       |
| `asg.security.appServer.urlPatterns` | URL Pattern for App Server | `"/*"`                                                                                                                                                                         |
| `asg.security.appServer.attributes.userName` | User name for App Server | `X-Remote-User`                                                                                                                                                                |
| `asg.security.appServer.attributes.groupNames` | Group name for App Server | `groups`                                                                                                                                                                       |
| `asg.security.appServer.attributes.groupSeparator` | Group Separator for App Server | `,`                                                                                                                                                                            |
| `asg.security.jwt.enabled` | Internal JWT | `false`                                                                                                                                                                        |
| `asg.security.jwt.serviceTokenSettings.urlPatterns` | URL Pattern for JWT | `/*`                                                                                                                                                                           |
| `asg.security.jwt.serviceTokenSettings.privateKey` | JWT Private Key | `<private Key>`                                                                                                                                                                |
| `asg.security.jwt.serviceTokenSettings.publicKey` | JWT Public Key | `<public Key>`                                                                                                                                                                 |
| `asg.security.jwt.serviceTokenSettings.expireSeconds` | Expiration for JWT | `36000`                                                                                                                                                                        |
| `asg.security.openidConnectTwo.enabled` | OpenidConnectTwo | `false`                                                                                                                                                                        |
| `asg.security.openidConnectTwo.outbound.` | Outbound for OpenidConnectTwo | `true`                                                                                                                                                                         |
| `asg.security.openidConnectTwo.validate.` | Validate OpenidConnectTwo | `true`                                                                                                                                                                         |
| `asg.security.openidConnectTwo.iamGroups.` | Enable iamGroups | `false`                                                                                                                                                                        |
| `asg.security.openidConnectTwo.whitelistIssuers.` | WhitelistIssuers for OpenidConnectTwo | `https://<HOST>:<PORT>/auth/realms/*`                                                                                                                                          |
| `asg.security.openidConnectTwo.mapping.userName` | Username to be mapped for OpenidConnectTwo | `preferred_username`                                                                                                                                                           |
| `asg.security.openidConnectTwo.mapping.groups` | Groups to be mapped for OpenidConnectTwo | `groups`                                                                                                                                                                       |
| `asg.security.iam.ldap.enabled` | Enable Identity and Access Managers with ldap type | `false`                                                                                                                                                                        |
| `asg.security.iam.ldap.server` | Server URL for ldap | `abc.com`                                                                                                                                                                      |
| `asg.security.iam.ldap.port` | Server port  for ldap | `389`                                                                                                                                                                          |
| `asg.security.iam.ldap.user` | User details for ldap | `CN=TEST,OU=Testing Accounts,OU=User Accounts,DC=asg,DC=com`                                                                                                                   |
| `asg.security.iam.ldap.password` | Password for ldap | `TEST`                                                                                                                                                                         |
| `asg.security.iam.ldap.groupDN` | groupDN for ldap | `DC=abc,DC=com`                                                                                                                                                                |
| `asg.security.iam.ldap.userDN` | userDN for ldap | `OU=User Accounts,DC=abc,DC=com`                                                                                                                                               |
| `asg.security.iam.ldap.userAttributes` | LDAP user attributes | `cn,memberof,proxyAddresses,textEncodedORAddress,mail`                                                                                                                         |
| `asg.security.iam.ldap.searchType` | Search type allowed | `CONTAINS`                                                                                                                                                                     |
| `logging.file` | File details for the logs generation | ``                                                                                                                                                                             |
| `logging.file.path` | File path in the local machine where logs can be generated | `${user.home}/asg/${spring.application.name}/logs`                                                                                                                             |
| `logging.file.name` | File name in the local machine where logs can be generated | `${user.home}/asg/${spring.application.name}/logs`                                                                                                                             |
| `logging.pattern` | Log pattern for the logs generation | ``                                                                                                                                                                             |
| `logging.pattern.file` | Patterns to be followed in log files | `%d{yyyy-MM-dd HH:mm:ss.SSS} %highlight{[%-5level]} %X{CORRELATION_ID} %X{TENANT}:%X{USER} %X{SERVICE} %style{[%t]}{magenta} %style{%c:%M}{cyan} - %replace{%msg}{[\r\n]}{}%n' |
| `logging.pattern.console` | Patterns to be followed in the console | `%d{yyyy-MM-dd HH:mm:ss.SSS} [%-5level] %X{CORRELATION_ID} %X{TENANT}:%X{USER} [%t] %c:%M - %replace{%msg}{[\r\n]}{}%n`                                                        |
| `logging.level.root` | Log level for the Spring framework logs | `INFO`                                                                                                                                                                         |
| `logging.level.com.asg.services` | Log level for CA Services | `ERROR`                                                                                                                                                                        |
| `logging.level.com.asg.common.authwrapper` | Log level for CA authwrapper | `ERROR`                                                                                                                                                                        |
| `logging.level.com.bpm.core` | Log level for CA bpm core | `ERROR`                                                                                                                                                                        |