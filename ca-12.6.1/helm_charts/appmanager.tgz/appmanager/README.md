# APP MANAGER

This is the Helm chart for the App Manager

## Prerequisites

- Docker with Kubernetes enabled
- HELM Cli

## Installing the chart
- Add our ASG Helm repository (use your Artifactory user and token):
  ```
  helm repo add rocket https://wal-artifactory.rocketsoftware.com/artifactory/mobf-helm-virtual-wal/ --username *** --password ***
  ```
- Check if AppManager chart is available:
  ```
  helm search appmanager
  ```
  The output should be like:
  ```
  NAME                         CHART VERSION    APP VERSION         DESCRIPTION                
  rocket/appmanager     4.0.0            4.0.0               App Manager Helm chart for Kubernetes
  ```
- You can inspect the chart with:
  ```
  helm inspect releasename rocket/appmanager --version 4.0.0
  ```

## Uninstalling the Chart

To uninstall/delete the `my-release` deployment:

```console
$ helm delete my-release
```

## Configuration

You can specify each property using the `--set key=value[,key=value]` argument to `helm install`.
Alternatively, a YAML file that specifies the values for the above parameters can be provided while installing the chart. For example,
For connecting to an external database, update the datasource.* configuration on your values.yaml and execute the below script.  

```
$ helm install rocket/appmanager --name my-release -f values.yaml
```
OR
```
$ helm install rocket/appmanager --name my-release --set spring.datasource.url=jdbc:postgresql://localhost:5432/roca
```


The following table lists the configurable parameters of the Content Automation chart and their default values.

| Parameter | Description                                                                                                                                                                                            | Default |
|--|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--|
| `image.repository` | Specify image docker registry and the name of the image	                                                                                                                                               | `{{docker-registry.url}}/appmanager` |
| `image.tag` | Container image version                                                                                                                                                                                | `4.0.0` |
| `image.pullPolicy` | Container image pull policy                                                                                                                                                                            | `IfNotPresent` |
| `nameOverride` | nameOverride is the name of the service to publish with                                                                                                                                                | ``
| `fullnameOverride` | fullnameOverride is the name of the service to publish with                                                                                                                                            | ``
| `service.type` | AppManager Service Type                                                                                                                                                                                | `NodePort` |
| `service.port` | AppManager Service Port                                                                                                                                                                                | `8521` |
| `livenessProbe.*` | Container liveness values                                                                                                                                                                              | `*` |
| `readinessProbe.*` | Container readiness values                                                                                                                                                                             | `*` |
| `resources` | CPU/Memory resource requests/limits, Recommended is 2/2Gi	                                                                                                                                             | `default` |
| `nodeSelector` | Node labels for pod assignment                                                                                                                                                                         | `{}` |
| `tolerations` | Toleration labels for pod assignment	                                                                                                                                                                  | `default` |
| `affinity` | Affinity settings for pod assignment                                                                                                                                                                   | `{}` |
| `replicaCount` | Deployment replicas of the POD                                                                                                                                                                         | `1` |
| `spring.datasource.url` | JDBC Database path with port no and databasename	                                                                                                                                                      | `jdbc:postgresql://<IP_ADDRESS>:<PORT>/roca` |
| `spring.datasource.driverClassName` | Java classpath for the Database driver	                                                                                                                                                                | `org.postgresql.Driver` |
| `spring.datasource.username` | JDBC Database username	                                                                                                                                                                                | `postgres` |
| `spring.datasource.password` | JDBC Database password	                                                                                                                                                                                | `postgres` |
| `spring.jpa.databasePlatform` | JPA Database platform                                                                                                                                                                                  | `org.hibernate.dialect.PostgreSQL9Dialect`
| `cloud.discovery.client.simple.instances.authorization.uri` | URI for Authorization service                                                                                                                                                                          | `http://<IP_ADDRESS>:<PORT>/mobius`
| `prs.service.client.location` | User location from where UI models are previewed                                                                                                                                                       | `/home/asg/Web`
| `prs.service.processEngineUrl` | Process Engine endpoint                                                                                                                                                                                | `http://<IP_ADDRESS>:<PORT>/flowable-rest`
| `prs.service.mobiusViewUrl` | Mobius Engine endpoint                                                                                                                                                                                 | `http://<IP_ADDRESS>:<PORT>/mobius/rest`
| `persistence.enabled` | Enable this property to use a peristence volume for AppManager templates                                                                                                                               | `false` |
| `persistence.volumeName` | Persistence volume name and need not be updated                                                                                                                                                        | `web-wcr` |
| `persistence.claimName` | Provide an existing Persistent Volume Claim, the value is evaluated as a template                                                                                                                      | `prs-efs` |
| `persistence.accessMode` | Persistence Volume Claim Access Mode for AppManager volume                                                                                                                                             | `ReadWriteMany` |
| `persistence.size` | Persistence Volume Claim Storage Request for AppManager volume                                                                                                                                         | `1Mi` |
| `persistence.hostPath` | Host Path for persistence	                                                                                                                                                                             | `/wcr` |
| `persistence.containerPath` | Container path for persistence	                                                                                                                                                                        | `/app/Web` |
| `persistence.storageClass` | Storage Class for persistence                                                                                                                                                                          | `efs` |
| `AdditionalVolumeMounts` | Used for mounting Additional Volumes                                                                                                                                                                   | 3 Mounts are available by default |
| `AdditionalVolumeMounts.name` | AdditionalVolumeMounts Name                                                                                                                                                                            | `prs-data` |
| `AdditionalVolumeMounts.mountPath` | Mount path for AdditionalVolumeMounts                                                                                                                                                                  | `/home/asg/Document_Store` |
| `AdditionalVolumeMounts.subPath` | Sub path for AdditionalVolumeMounts                                                                                                                                                                    | `Document_Store` |
| `AdditionalVolumeMounts.name` | AdditionalVolumeMounts Name                                                                                                                                                                            | `prs-data` |
| `AdditionalVolumeMounts.mountPath` | Mount path for AdditionalVolumeMounts                                                                                                                                                                  | `/home/asg/Web` |
| `AdditionalVolumeMounts.subPath` | Sub path for AdditionalVolumeMounts                                                                                                                                                                    | `Web` |
| `AdditionalVolumeMounts.name` | AdditionalVolumeMounts Name                                                                                                                                                                            | `prs-data` |
| `AdditionalVolumeMounts.mountPath` | Mount path for AdditionalVolumeMounts                                                                                                                                                                  | `/home/asg/web_wcr` |
| `AdditionalVolumeMounts.subPath` | Sub path for AdditionalVolumeMounts                                                                                                                                                                    | `web_wcr` |
| `AdditionalVolumes` | Additional Volumes for AppManager                                                                                                                                                                      | `` |
| `AdditionalVolumes.name` | Additional Volumes Name                                                                                                                                                                                | `prs-data` |
| `AdditionalVolumes.persistentVolumeClaim.claiName` | Claim name for Persistent Volume                                                                                                                                                                       | `prs-efs` |
| `server.ssl.enabled` | Used for enabling SSL Configuration                                                                                                                                                                    | `false` |
| `server.ssl.protocol` | Protocol used in the SSL                                                                                                                                                                               | `TLS` |
| `server.ssl.enabledProtocols` | Protocol enabled in the SSL                                                                                                                                                                            | `TLSv1.2` |
| `server.ssl.trustStore` | Trust Store file path                                                                                                                                                                                  | `cert/trust_store.pfx` |
| `server.ssl.trustStorePassword` | Trust Store file password                                                                                                                                                                              | `password` |
| `server.ssl.keystoreType` | Keystore Type                                                                                                                                                                                          | `PKCS12` |
| `ports.name` | Name of the port                                                                                                                                                                                       | `http` |
| `ports.containerPort` | ContainerPort is the port where container should run                                                                                                                                                   | `8521` |
| `ports.targetPort` | TargetPort is the port where the service points to                                                                                                                                                     | `8521` |
| `ports.protocol` | Name of the protocol                                                                                                                                                                                   | `TCP` |
| `asg.security.enabled` | Enable security features, recommended to be enabled                                                                                                                                                    | `true` |
| `asg.security.basicauth.inbound` | Inbound for Basic Auth, not recommended for Production. Set to false on Production                                                                                                                     | `true` |
| `asg.security.basicauth.username` | Username for basic auth                                                                                                                                                                                | `admin` |
| `asg.security.basicauth.password` | Password for basic auth                                                                                                                                                                                | `admin` |
| `asg.security.basicauth.groups` | Groups required for basic auth | `ContentAutomationUser,ContentAutomationAdmin` |
| `asg.security.appServer.enabled` | App Server security with Proxy                                                                                                                                                                         | `false` |
| `asg.security.appServer.type` | App Server Type                                                                                                                                                                                        | `CUSTOM` |
| `asg.security.appServer.attributes.userName` | User name for App Server                                                                                                                                                                               | `X-Remote-User` |
| `asg.security.appServer.attributes.groupNames` | Group name for App Server                                                                                                                                                                              | `groups` |
| `asg.security.appServer.attributes.groupSeparator` | Group Separator for App Server                                                                                                                                                                         | `,` |
| `asg.security.jwt.enabled` | Internal JWT                                                                                                                                                                                           | `false` |
| `asg.security.jwt.serviceTokenSettings.privateKey` | JWT Private Key                                                                                                                                                                                        | `<private Key>` |
| `asg.security.jwt.serviceTokenSettings.publicKey` | JWT Public Key                                                                                                                                                                                         | `<public Key>` |
| `asg.security.jwt.serviceTokenSettings.expireSeconds` | Expiration for JWT                                                                                                                                                                                     | `36000` |
| `asg.security.openidConnectTwo.enabled` | Enables the OpenidConnectTwo filter                                                                                                                                                                    | `false` |
| `asg.security.openidConnectTwo.outbound.` | Determines if the JWT should be passed downstream or not.                                                                                                                                              | `true` |
| `asg.security.openidConnectTwo.validate.` | Enables JWT's identity token signature validation                                                                                                                                                      | `true` |
| `asg.security.openidConnectTwo.iamGroups.` | Determines if the groups should be retrieved the Identity Access Manager                                                                                                                               | `false` |
| `asg.security.openidConnectTwo.whitelistIssuers.` | If there is a whitelist, then issuer, within the JWT must be in the list. If there is no entries in the whitelist, then nothing is allowed. If you put an asterisk, then any JWT is allowed, if valid. | `https://<HOST>:<PORT>/auth/realms/*` |
| `asg.security.openidConnectTwo.mapping.userName` | Reads the configured username in case of access token                                                                                                                                                  | `preferred_username` |
| `asg.security.openidConnectTwo.mapping.groups` | Groups to be mapped for OpenidConnectTwo                                                                                                                                                               | `groups` |
| `asg.security.iam.ldap.enabled` | Enable Identity and Access Managers with ldap type                                                                                                                                                     | `false` |
| `asg.security.iam.ldap.server` | Server URL for ldap                                                                                                                                                                                    | `abc.com` |
| `asg.security.iam.ldap.port` | Server port  for ldap                                                                                                                                                                                  | `389` |
| `asg.security.iam.ldap.user` | User details for ldap                                                                                                                                                                                  | `CN=TEST,OU=Testing Accounts,OU=User Accounts,DC=asg,DC=com` |
| `asg.security.iam.ldap.password` | Password for ldap                                                                                                                                                                                      | `TEST` |
| `asg.security.iam.ldap.groupDN` | groupDN for ldap                                                                                                                                                                                       | `DC=abc,DC=com` |
| `asg.security.iam.ldap.userDN` | userDN for ldap                                                                                                                                                                                        | `OU=User Accounts,DC=abc,DC=com` |
| `asg.security.iam.ldap.userAttributes` | LDAP user attributes                                                                                                                                                                                   | `cn,memberof,proxyAddresses,textEncodedORAddress,mail` |
| `asg.security.iam.ldap.searchType` | Search type allowed                                                                                                                                                                                    | `CONTAINS` |
| `asg.security.authorization.enabled` | To enable Authorization service Configuration                                                                                                                                                          | `false` |
| `logging.file` | File details for the logs generation                                                                                                                                                                   | `` |
| `logging.file.path` | File path in the local machine where logs can be generated                                                                                                                                             | `${user.home}/asg/${spring.application.name}/logs` |
| `logging.file.name` | File name in the local machine where logs can be generated                                                                                                                                             | `${user.home}/asg/${spring.application.name}/logs` |
| `logging.pattern` | Log pattern for the logs generation                                                                                                                                                                    | `` |
| `logging.pattern.console` | Patterns to be followed in log files                                                                                                                                                                   | `%d{yyyy-MM-dd HH:mm:ss.SSS} %highlight{[%-5level]} %X{CORRELATION_ID} %X{TENANT}:%X{USER} %X{SERVICE} %style{[%t]}{magenta} %style{%c:%M}{cyan} - %replace{%msg}{[\r\n]}{}%n' |
| `logging.pattern.file` | Patterns to be followed in the console                                                                                                                                                                 | `%d{yyyy-MM-dd HH:mm:ss.SSS} [%-5level] %X{CORRELATION_ID} %X{TENANT}:%X{USER} [%t] %c:%M - %replace{%msg}{[\r\n]}{}%n` |
| `logging.level.root` | Log level for the Spring framework logs                                                                                                                                                                | `INFO` |
| `logging.level.com.asg.services` | Log level for CA Services                                                                                                                                                                              | `Error` |
| `logging.level.com.asg.common.authwrapper` | Log level for CA authwrapper                                                                                                                                                                           | `Error` |
| `logging.level.com.bpm.com` | Log level for CA bpm core                                                                                                                                                                              | `Error` |

