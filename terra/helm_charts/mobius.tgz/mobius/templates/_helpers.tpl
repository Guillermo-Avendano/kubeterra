{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "mobius.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "mobius.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "mobius.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "mobius.apmApiKeySecretName" -}}
{{- if .Values.mobius.elasticapm.apmApiKey }}
{{ include "mobius.fullname" . }}-apm-apikey
{{- else -}}
{{ .Values.mobius.elasticapm.apmApiKeySecretName }}
{{- end -}}
{{- end -}}

{{- define "mobius.apmApiKeySecretKey" -}}
{{- if .Values.mobius.elasticapm.apmApiKey }}
apmApiKey
{{- else -}}
{{ .Values.mobius.elasticapm.apmApiKeySecretKey }}
{{- end -}}
{{- end -}}

{{- define "mobius.apmSecretTokenName" -}}
{{- if .Values.mobius.elasticapm.apmSecretToken }}
{{ include "mobius.fullname" . }}-apm-secrettoken
{{- else -}}
{{ .Values.mobius.elasticapm.apmSecretName }}
{{- end -}}
{{- end -}}

{{- define "mobius.apmSecretTokenKey" -}}
{{- if .Values.mobius.elasticapm.apmSecretToken }}
apmSecretToken
{{- else -}}
{{ .Values.mobius.elasticapm.apmSecretKey }}
{{- end -}}
{{- end -}}

{{- define "mobius.splunkSecretName" -}}
{{- if .Values.mobius.mobiusDiagnostics.fluentBitLogging.splunk.splunkSecretToken }}
{{ include "mobius.fullname" . }}-splunk-secrettoken
{{- else -}}
{{ .Values.mobius.mobiusDiagnostics.fluentBitLogging.splunk.splunkSecretName }}
{{- end -}}
{{- end -}}

{{- define "mobius.splunkSecretKey" -}}
{{- if .Values.mobius.mobiusDiagnostics.fluentBitLogging.splunk.splunkSecretToken }}
splunkSecretToken
{{- else -}}
{{ .Values.mobius.mobiusDiagnostics.fluentBitLogging.splunk.splunkSecretKey }}
{{- end -}}
{{- end -}}

