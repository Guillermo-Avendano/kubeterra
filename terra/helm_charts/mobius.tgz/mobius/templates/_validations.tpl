{{/* ---- Enforce only one autoscaler enabled ---- */}}
{{- define "mobius.validate.autoscaling.mutualExclusion" -}}
{{- if and .Values.autoscaling.hpa.enabled .Values.autoscaling.keda.enabled }}
{{- fail "You cannot enable both HPA and KEDA at the same time. Please set only one to enabled under 'autoscaling'." }}
{{- end }}
{{- end }}

{{/* ---- HPA Validations ---- */}}
{{- define "mobius.validate.autoscaling.hpa" -}}
{{- if (and .Values.autoscaling .Values.autoscaling.hpa .Values.autoscaling.hpa.enabled) }}

  {{- if not (hasKey .Values.autoscaling.hpa "minReplicas") }}
  {{- fail "HPA enabled but minReplicas is not defined" }}
  {{- end }}

  {{- if not (hasKey .Values.autoscaling.hpa "maxReplicas") }}
  {{- fail "HPA enabled but maxReplicas is not defined" }}
  {{- end }}

  {{- if not (or .Values.autoscaling.hpa.targetCPUUtilizationPercentage .Values.autoscaling.hpa.targetMemoryUtilizationPercentage) }}
  {{- fail "HPA enabled but neither targetCPUUtilizationPercentage nor targetMemoryUtilizationPercentage is defined" }}
  {{- end }}

  {{- if and .Values.autoscaling.hpa.targetCPUUtilizationPercentage .Values.autoscaling.hpa.targetMemoryUtilizationPercentage }}
  {{- if or (not (hasKey .Values.resources.requests "cpu")) (not (hasKey .Values.resources.requests "memory")) }}
  {{- fail "Combined CPU+Memory autoscaling requires both resources.requests.cpu and resources.requests.memory to be defined" }}
  {{- end }}
  {{- end }}

  {{- if and .Values.autoscaling.hpa.targetCPUUtilizationPercentage (not (hasKey .Values.resources.requests "cpu")) }}
  {{- fail "CPU autoscaling requires resources.requests.cpu to be defined" }}
  {{- end }}

  {{- if and .Values.autoscaling.hpa.targetMemoryUtilizationPercentage (not (hasKey .Values.resources.requests "memory")) }}
  {{- fail "Memory autoscaling requires resources.requests.memory to be defined" }}
  {{- end }}
{{- end }}
{{- end }}

{{/* ---- KEDA Validations ---- */}}
{{- define "mobius.validate.autoscaling.keda" -}}
{{- if and .Values.autoscaling .Values.autoscaling.keda .Values.autoscaling.keda.enabled -}}

  {{- if not .Values.autoscaling.keda.minReplicas }}
    {{ fail "KEDA enabled but minReplicas is not defined" }}
  {{- end }}

  {{- if not .Values.autoscaling.keda.maxReplicas }}
    {{ fail "KEDA enabled but maxReplicas is not defined" }}
  {{- end }}

  {{- if lt (int .Values.autoscaling.keda.minReplicas) 1 }}
    {{ fail "KEDA validation failed: minReplicas must be at least 1" }}
  {{- end -}}

  {{- if gt (int .Values.autoscaling.keda.minReplicas) (int .Values.autoscaling.keda.maxReplicas) }}
    {{ fail "KEDA validation failed: minReplicas cannot be greater than maxReplicas" }}
  {{- end }}

  {{- if not (hasKey .Values.autoscaling.keda "pollingInterval") }}
    {{ fail "KEDA validation failed: pollingInterval must be set" }}
  {{- end }}

  {{- if lt (int .Values.autoscaling.keda.pollingInterval) 1 }}
    {{ fail "KEDA validation failed: pollingInterval must be greater than zero" }}
  {{- end }}

  {{- if not .Values.autoscaling.keda.cooldownPeriod }}
    {{ fail "KEDA validation failed: cooldownPeriod must be set" }}
  {{- end }}

  {{- if lt (int .Values.autoscaling.keda.cooldownPeriod) 1 }}
    {{ fail "KEDA validation failed: cooldownPeriod must be greater than zero" }}
  {{- end }}

  {{- if not .Values.autoscaling.keda.triggers -}}
    {{ fail "KEDA validation failed: KEDA enabled but no triggers defined" }}
  {{- end -}}

  {{- range $i, $t := .Values.autoscaling.keda.triggers -}}

    {{- if eq $t.type "prometheus" -}}
      {{- if not $t.metadata.serverAddress -}}
        {{ fail (printf "KEDA validation failed: Prometheus requires metadata.serverAddress") }}
      {{- end -}}
      {{- if not (regexMatch "^https?://" $t.metadata.serverAddress) -}}
        {{ fail (printf "KEDA validation failed: Prometheus serverAddress must start with http:// or https://, got %s" $t.metadata.serverAddress) }}
      {{- end -}}
      {{- if not $t.metadata.query -}}
        {{ fail (printf "KEDA validation failed: Prometheus requires metadata.query") }}
      {{- end -}}
      {{- if eq (trim $t.metadata.query) "" -}}
        {{ fail "KEDA validation failed: Prometheus query cannot be empty" }}
      {{- end -}}
      {{- if not $t.metadata.threshold -}}
        {{ fail (printf "KEDA validation failed: Prometheus requires metadata.threshold") }}
      {{- end -}}
      {{- if hasKey $t "authenticationRef" -}}
        {{- if not $t.authenticationRef.name -}}
          {{ fail (printf "KEDA validation failed: authenticationRef.name is required") }}
        {{- end -}}
      {{- end -}}
      {{- if and $t.authenticationRef (not $t.metadata.authModes) -}}
        {{ fail (printf "KEDA validation failed: Prometheus requires metadata.authModes when authenticationRef is set") }}
      {{- end -}}
    {{- end -}}

    {{- if eq $t.type "metrics-api" -}}
      {{- if not $t.metadata.metricName -}}
        {{ fail (printf "KEDA validation failed: metrics-api requires metadata.metricName") }}
      {{- end -}}
      {{- if not $t.metadata.url -}}
        {{ fail (printf "KEDA validation failed: metrics-api requires metadata.url") }}
      {{- end -}}
      {{- if not $t.metadata.targetValue -}}
        {{ fail (printf "KEDA validation failed: metrics-api requires metadata.targetValue") }}
      {{- end -}}
    {{- end -}}

    {{- if eq $t.type "cpu" -}}
      {{- if not $t.metricType -}}
        {{ fail (printf "KEDA validation failed: CPU requires metricType") }}
      {{- end -}}
      {{- if not $t.metadata.value -}}
        {{ fail (printf "KEDA validation failed: CPU requires metadata.value") }}
      {{- end -}}
      {{- if not $t.metadata.containerName -}}
        {{ fail (printf "KEDA validation failed: CPU requires metadata.containerName") }}
      {{- end -}}
    {{- end -}}

    {{- if eq $t.type "memory" -}}
      {{- if not $t.metricType -}}
        {{ fail (printf "KEDA validation failed: Memory requires metricType") }}
      {{- end -}}
      {{- if not $t.metadata.value -}}
        {{ fail (printf "KEDA validation failed: Memory requires metadata.value") }}
      {{- end -}}
      {{- if not $t.metadata.containerName -}}
        {{ fail (printf "KEDA validation failed: Memory requires metadata.containerName") }}
      {{- end -}}
    {{- end -}}

  {{- end -}}  {{/* This closes the range triggers */}}

{{- end -}}    {{/* This closes the initial "if KEDA enabled" */}}
{{- end }}     {{/* This closes the define block */}}