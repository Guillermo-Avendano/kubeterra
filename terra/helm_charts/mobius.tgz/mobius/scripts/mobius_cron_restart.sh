#!/bin/bash
set -e
NAMESPACE="{{ .Values.namespace }}"
STATEFULSET="{{ include "mobius.fullname" . }}"
INSTANCE_LABEL="{{ .Release.Name }}"
CONTAINER_NAME="{{ .Chart.Name }}"
CPU_THRESHOLD={{ get (get .Values.cronjob "restart" | default dict) "cpuThreshold" | default 5 }}
# Initial delay = (number of pods × 250 sec) + 30 sec interval with max 30 retries, giving a extra grace period of 15 mins
CHECK_INTERVAL=30
MAX_RETRIES=30
MAX_SLEEP_RETRY=12
SLEEP_TIME=1800
HIGH_CPU=false
failures=0

echo "NAMESPACE: $NAMESPACE"
echo "STATEFULSET: $STATEFULSET"
echo "INSTANCE_LABEL: $INSTANCE_LABEL"
echo "CONTAINER_NAME: $CONTAINER_NAME"
echo "CPU_THRESHOLD: $CPU_THRESHOLD"

run_cmd() {
  echo "[COMMAND] $*"
  output=$(eval "$@")
  echo "[OUTPUT]"
  echo "$output"
  echo ""
}

print_sts_status() {
  echo "StatefulSet status for $STATEFULSET:"
  run_cmd kubectl get statefulset "$STATEFULSET" -n "$NAMESPACE"
  echo "Pods for $STATEFULSET:"
  run_cmd kubectl get pods -n "$NAMESPACE" -l app.kubernetes.io/instance="$INSTANCE_LABEL"
}

check_pods_running() {
  for ((i=1; i<=MAX_RETRIES; i++)); do
    pods=$(kubectl get pods -n "$NAMESPACE" -l app.kubernetes.io/instance="$INSTANCE_LABEL" --no-headers)
    all_ready=true
    while read -r pod_line; do
      [[ -z "$pod_line" ]] && continue
      ready=$(echo "$pod_line" | awk '{print $2}')
      status=$(echo "$pod_line" | awk '{print $3}')
      ready_count=$(echo "$ready" | cut -d'/' -f1)
      total_count=$(echo "$ready" | cut -d'/' -f2)
      if [[ "$ready_count" != "$total_count" || "$status" != "Running" ]]; then
        all_ready=false
        break
      fi
    done <<< "$pods"
    if $all_ready; then
      return 0
    fi
    sleep $CHECK_INTERVAL
  done
  return 1
}

# Function to calculate the average CPU utilization for a container in a StatefulSet
calculate_average_cpu() {
  NUM_POLLS=0             # Number of polling intervals
  SUM_OF_POLL_AVG=0       # Sum of poll averages (per poll: utilization across running pods)
  TOTAL_AVG_UTIL=0        # Final average utilization (across all polls)

  echo "Checking average CPU utilization for StatefulSet $STATEFULSET (container: $CONTAINER_NAME)..."

  for i in {1..12}; do
    pods=$(kubectl get pods -n "$NAMESPACE" -l app.kubernetes.io/instance="$INSTANCE_LABEL" --field-selector=status.phase=Running -o json 2>/dev/null | jq -r '.items[].metadata.name')
    CURRENT_POLL_UTIL_SUM=0
    POD_COUNT=0

    for pod in $pods; do
      usage=$(kubectl top pod "$pod" -n "$NAMESPACE" --containers --no-headers 2>/dev/null | awk -v c="$CONTAINER_NAME" '$2==c {sub(/m$/,"",$3); print $3}')
      request=$(kubectl get pod "$pod" -n "$NAMESPACE" -o json 2>/dev/null | jq -r ".spec.containers[] | select(.name==\"$CONTAINER_NAME\") | .resources.requests.cpu // \"0\"")
      if [[ "$request" == *m ]]; then
        # Already in millicores; strip 'm'
        request="${request%m}"
      elif [[ "$request" =~ ^[0-9]+(\.[0-9]+)?$ ]]; then
        # Cores (integer or decimal): multiply by 1000 to get millicores
        request=$(awk "BEGIN {printf \"%d\", $request * 1000}")
      else
        # Empty input
        request=0
      fi
      # Calculate utilization if both usage and request are available
      if [[ -n "$usage" && -n "$request" && "$request" -gt 0 ]]; then
        util=$(awk "BEGIN {printf \"%.2f\", ($usage/$request)*100}")
        CURRENT_POLL_UTIL_SUM=$(awk "BEGIN {printf \"%.2f\", $CURRENT_POLL_UTIL_SUM+$util}")
        POD_COUNT=$((POD_COUNT + 1))
        echo "Poll $i Pod: $pod, Usage: ${usage}m, Request: ${request}m, Utilization: ${util}%"
      else
        echo "Poll $i Pod: $pod - Usage or request unavailable, skipping."
      fi
    done

    # Only count polls that had at least one valid pod
    if (( POD_COUNT > 0 )); then
      POLL_AVG=$(awk "BEGIN {printf \"%.2f\", $CURRENT_POLL_UTIL_SUM/$POD_COUNT}")
      echo "Poll $i average utilization across $POD_COUNT pods: $POLL_AVG%"
      SUM_OF_POLL_AVG=$(awk "BEGIN {printf \"%.2f\", $SUM_OF_POLL_AVG+$POLL_AVG}")
      NUM_POLLS=$((NUM_POLLS + 1))
    else
      echo "Poll $i: No valid pod utilization collected."
    fi

    sleep 10
  done

  # If no polls had data, warn and allow restart
  if (( NUM_POLLS == 0 )); then
    echo "Error: No utilization data collected in any poll. Aborting restart!"
    TOTAL_AVG_UTIL=0
    exit 1  # No data: DO NOT allow restart; abort script with error
  fi

  TOTAL_AVG_UTIL=$(awk "BEGIN {printf \"%.0f\", $SUM_OF_POLL_AVG/$NUM_POLLS}")
  echo "Calculated average CPU utilization for container '$CONTAINER_NAME' over all polls: $TOTAL_AVG_UTIL%"

  # Return 1 if CPU is high, 0 if not
  if [[ "$TOTAL_AVG_UTIL" -gt "$CPU_THRESHOLD" ]]; then
    echo "Average CPU utilization $TOTAL_AVG_UTIL% is ABOVE threshold $CPU_THRESHOLD%"
    return 1  # CPU is high
  else
    echo "Average CPU utilization $TOTAL_AVG_UTIL% is BELOW or equal to threshold $CPU_THRESHOLD%"
    return 0  # CPU not high
  fi
}

# Get pod count for the statefulset
POD_COUNT=$(kubectl get statefulset "$STATEFULSET" -n "$NAMESPACE" -o jsonpath='{.spec.replicas}')
# Calculate INITIAL_DELAY as pod_count * 250 seconds
INITIAL_DELAY=$((POD_COUNT * 250))
echo "============================================= BEFORE RESTART =============================================="
print_sts_status

# Logic for cpuThreshold < 0: always proceed immediately with restart
if [[ "$CPU_THRESHOLD" -lt 0 ]]; then
  echo "CPU threshold is $CPU_THRESHOLD (<0): Skipping CPU check and proceeding with rollout restart."
  HIGH_CPU=false
else
  # Check average CPU utilization before attempting a restart
  if ! calculate_average_cpu; then
    echo "High CPU detected for STATEFULSET $STATEFULSET"
    retry_count=0
    while [[ $retry_count -lt $MAX_SLEEP_RETRY ]]; do
      echo "Sleeping for $SLEEP_TIME seconds before next utilization check..."
      sleep "$SLEEP_TIME"  # sleeping for 30 minutes
      if calculate_average_cpu; then
        echo "CPU below threshold for $STATEFULSET after $((retry_count + 1)) retries."
        break
      fi
      retry_count=$((retry_count + 1))
    done
    if ! calculate_average_cpu; then
      # CPU still high after all retries, skip restart
      HIGH_CPU=true
      echo "CPU still high for $STATEFULSET after $MAX_SLEEP_RETRY retries. Restart will be skipped."
    else
      echo "CPU is now below threshold for $STATEFULSET after waiting."
    fi
  else
    HIGH_CPU=false
    echo "CPU was initially below threshold for $STATEFULSET. Proceeding without retries."
  fi
fi

if [[ "$HIGH_CPU" == "true" ]]; then
  echo "--- SERVER CPU IS HIGH . Skipping restart ---"
else
  echo "--- Proceeding with restart ---"
  echo "Rollout restart for $STATEFULSET in namespace $NAMESPACE started at $(date "+%Y-%m-%d %H:%M:%S")"
  run_cmd kubectl rollout restart statefulset/"$STATEFULSET" -n "$NAMESPACE"
  echo "Sleeping for INITIAL_DELAY of $INITIAL_DELAY seconds for $STATEFULSET (Pods: $POD_COUNT)"
  run_cmd kubectl rollout status statefulset/"$STATEFULSET" -n "$NAMESPACE" --timeout=${INITIAL_DELAY}s
  echo "Rollout restart finished for $STATEFULSET at $(date "+%Y-%m-%d %H:%M:%S")"
  echo "============================================= AFTER RESTART ==============================================="
  echo "Current $STATEFULSET status at $(date "+%Y-%m-%d %H:%M:%S")"
  echo ""
  print_sts_status
  echo "======================================================================================================="
  if check_pods_running; then
    echo "SUCCESS: StatefulSet $STATEFULSET pods are running at $(date "+%Y-%m-%d %H:%M:%S")"
  else
    TOTAL_WAIT_MINUTES=$(((INITIAL_DELAY + CHECK_INTERVAL * MAX_RETRIES) / 60))
    echo "FAILURE: StatefulSet $STATEFULSET pods not running after $TOTAL_WAIT_MINUTES minutes (including initial delay) at $(date "+%Y-%m-%d %H:%M:%S")"
    failures=$((failures+1))
  fi

  print_sts_status

  echo "======================================================================================================="

  if [[ "$failures" -gt 0 ]]; then
    echo "Final check at $(date "+%Y-%m-%d %H:%M:%S"): StatefulSet $STATEFULSET failed to restart"
  else
    echo "Final check at $(date "+%Y-%m-%d %H:%M:%S"): StatefulSet $STATEFULSET restarted and running successfully"
  fi

fi