{{/* vim: set filetype=mustache: */}}
#######################################################################################
##  Umbrella Chart Helpers
#######################################################################################
{{/*
Expand the name of the chart.
*/}}
{{- define "content-automation.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "content-automation.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "content-automation.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "content-automation.labels" -}}
helm.sh/chart: {{ include "content-automation.chart" . }}
{{ include "content-automation.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "content-automation.selectorLabels" -}}
app.kubernetes.io/name: {{ include "content-automation.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "content-automation.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "content-automation.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}


#######################################################################################
##  Studio Helpers
#######################################################################################
{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "studio.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "studio.fullname" -}}
{{- if .Values.studio.fullnameOverride -}}
{{- .Values.studio.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default "studio" .Values.studio.nameOverride -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "studio.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "studio.labels" -}}
app.kubernetes.io/name: {{ include "studio.name" . }}
helm.sh/chart: {{ include "studio.chart" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}


#######################################################################################
##  Appmanager Helpers
#######################################################################################
{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "appmanager.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "appmanager.fullname" -}}
{{- if .Values.appmanager.fullnameOverride -}}
{{- .Values.appmanager.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default "appmanager" .Values.appmanager.nameOverride -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "appmanager.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "appmanager.labels" -}}
app.kubernetes.io/name: {{ include "appmanager.name" . }}
helm.sh/chart: {{ include "appmanager.chart" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

#######################################################################################
##  Process Engine Helpers
#######################################################################################
{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "processengine.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "processengine.fullname" -}}
{{- if .Values.processengine.fullnameOverride -}}
{{- .Values.processengine.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default "processengine" .Values.processengine.nameOverride -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "processengine.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "processengine.labels" -}}
app.kubernetes.io/name: {{ include "processengine.name" . }}
helm.sh/chart: {{ include "processengine.chart" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

#######################################################################################
##  Environment Variable Templates (to avoid duplication in combined/separate modes)
#######################################################################################

{{/*
Studio database environment variables
*/}}
{{- define "studio.database.env" -}}
{{- if .Values.studio.spring.datasource.databaseConnectivitySecretName }}
- name: SPRING_DATASOURCE_URL
  valueFrom:
    secretKeyRef:
      name: {{ .Values.studio.spring.datasource.databaseConnectivitySecretName }}
      key: {{ .Values.spring.datasource.databaseUrlSecretValue }}
- name: SPRING_DATASOURCE_USERNAME
  valueFrom:
    secretKeyRef:
      name: {{ .Values.studio.spring.datasource.databaseConnectivitySecretName }}
      key: {{ .Values.spring.datasource.databaseUsernameSecretValue }}
- name: SPRING_DATASOURCE_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ .Values.studio.spring.datasource.databaseConnectivitySecretName }}
      key: {{ .Values.spring.datasource.databasePasswordSecretValue }}
{{- else }}
- name: SPRING_DATASOURCE_URL
  value: '{{ .Values.spring.datasource.studio.url }}'
- name: SPRING_DATASOURCE_USERNAME
  value: '{{ .Values.spring.datasource.studio.username }}'
- name: SPRING_DATASOURCE_PASSWORD
  value: '{{ .Values.spring.datasource.studio.password }}'
{{- end }}
- name: SPRING_DATASOURCE_DRIVERCLASSNAME
  value: '{{ .Values.spring.datasource.studio.driverClassName }}'
- name: SPRING_JPA_HIBERNATE_DDLAUTO
  value: '{{ .Values.studio.spring.jpa.hibernate.ddlAuto }}'
{{- /* Studio Smart Extractor Metadata DataSource (REQUIRED FOR ORACLE) */ -}}
{{- /* First check if studio-smart-extractor key exists (not commented out) */ -}}
{{- $studioSmartExtractor := index .Values.spring.datasource "studio-smart-extractor" -}}
{{- if $studioSmartExtractor }}
  {{- /* Then check if url exists and is not empty */ -}}
  {{- $studioSmartExtractorUrl := index $studioSmartExtractor "url" -}}
  {{- if and $studioSmartExtractorUrl (ne $studioSmartExtractorUrl "") }}
- name: SPRING_DATASOURCE_STUDIO_SMART_EXTRACTOR_URL
  value: '{{ $studioSmartExtractorUrl }}'
- name: SPRING_DATASOURCE_STUDIO_SMART_EXTRACTOR_USERNAME
  value: '{{ index $studioSmartExtractor "username" }}'
- name: SPRING_DATASOURCE_STUDIO_SMART_EXTRACTOR_PASSWORD
  value: '{{ index $studioSmartExtractor "password" }}'
- name: SPRING_DATASOURCE_STUDIO_SMART_EXTRACTOR_DRIVER_CLASS_NAME
  value: '{{ index $studioSmartExtractor "driver-class-name" }}'
  {{- end }}
{{- end }}
{{- end -}}

{{/*
AppManager database environment variables
*/}}
{{- define "appmanager.database.env" -}}
{{- if .Values.appmanager.spring.datasource.databaseConnectivitySecretName }}
- name: SPRING_DATASOURCE_URL
  valueFrom:
    secretKeyRef:
      name: {{ .Values.appmanager.spring.datasource.databaseConnectivitySecretName }}
      key: {{ .Values.spring.datasource.databaseUrlSecretValue }}
- name: SPRING_DATASOURCE_USERNAME
  valueFrom:
    secretKeyRef:
      name: {{ .Values.appmanager.spring.datasource.databaseConnectivitySecretName }}
      key: {{ .Values.spring.datasource.databaseUsernameSecretValue }}
- name: SPRING_DATASOURCE_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ .Values.appmanager.spring.datasource.databaseConnectivitySecretName }}
      key: {{ .Values.spring.datasource.databasePasswordSecretValue }}
{{- else }}
- name: SPRING_DATASOURCE_URL
  value: '{{ .Values.spring.datasource.appmanager.url }}'
- name: SPRING_DATASOURCE_USERNAME
  value: '{{ .Values.spring.datasource.appmanager.username }}'
- name: SPRING_DATASOURCE_PASSWORD
  value: '{{ .Values.spring.datasource.appmanager.password }}'
{{- end }}
- name: SPRING_DATASOURCE_DRIVERCLASSNAME
  value: '{{ .Values.spring.datasource.appmanager.driverClassName }}'
{{- /* AppManager Smart Extractor Metadata DataSource (REQUIRED FOR ORACLE) */ -}}
{{- /* First check if appmanager-smart-extractor key exists (not commented out) */ -}}
{{- $appmanagerSmartExtractor := index .Values.spring.datasource "appmanager-smart-extractor" -}}
{{- if $appmanagerSmartExtractor }}
  {{- /* Then check if url exists and is not empty */ -}}
  {{- $appmanagerSmartExtractorUrl := index $appmanagerSmartExtractor "url" -}}
  {{- if and $appmanagerSmartExtractorUrl (ne $appmanagerSmartExtractorUrl "") }}
- name: SPRING_DATASOURCE_APPMANAGER_SMART_EXTRACTOR_URL
  value: '{{ $appmanagerSmartExtractorUrl }}'
- name: SPRING_DATASOURCE_APPMANAGER_SMART_EXTRACTOR_USERNAME
  value: '{{ index $appmanagerSmartExtractor "username" }}'
- name: SPRING_DATASOURCE_APPMANAGER_SMART_EXTRACTOR_PASSWORD
  value: '{{ index $appmanagerSmartExtractor "password" }}'
- name: SPRING_DATASOURCE_APPMANAGER_SMART_EXTRACTOR_DRIVER_CLASS_NAME
  value: '{{ index $appmanagerSmartExtractor "driver-class-name" }}'
  {{- end }}
{{- end }}
{{- end -}}

{{/*
ProcessEngine database environment variables
*/}}
{{- define "processengine.database.env" -}}
{{- if .Values.processengine.spring.datasource.flowable.databaseConnectivitySecretName }}
- name: SPRING_DATASOURCE_FLOWABLE_URL
  valueFrom:
    secretKeyRef:
      name: {{ .Values.processengine.spring.datasource.flowable.databaseConnectivitySecretName }}
      key: {{ .Values.spring.datasource.databaseUrlSecretValue }}
- name: SPRING_DATASOURCE_FLOWABLE_USERNAME
  valueFrom:
    secretKeyRef:
      name: {{ .Values.processengine.spring.datasource.flowable.databaseConnectivitySecretName }}
      key: {{ .Values.spring.datasource.databaseUsernameSecretValue }}
- name: SPRING_DATASOURCE_FLOWABLE_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ .Values.processengine.spring.datasource.flowable.databaseConnectivitySecretName }}
      key: {{ .Values.spring.datasource.databasePasswordSecretValue }}
{{- else }}
- name: SPRING_DATASOURCE_FLOWABLE_URL
  value: '{{ .Values.spring.datasource.processengine.flowable.url }}'
- name: SPRING_DATASOURCE_FLOWABLE_USERNAME
  value: '{{ .Values.spring.datasource.processengine.flowable.username }}'
- name: SPRING_DATASOURCE_FLOWABLE_PASSWORD
  value: '{{ .Values.spring.datasource.processengine.flowable.password }}'
{{- end }}
- name: SPRING_DATASOURCE_FLOWABLE_DRIVERCLASSNAME
  value: '{{ .Values.spring.datasource.processengine.flowable.driverClassName }}'
{{- if .Values.processengine.spring.datasource.root.databaseConnectivityRootSecretName }}
- name: SPRING_DATASOURCE_ROOT_URL
  valueFrom:
    secretKeyRef:
      name: {{ .Values.processengine.spring.datasource.root.databaseConnectivityRootSecretName }}
      key: {{ .Values.spring.datasource.databaseUrlSecretValue }}
- name: SPRING_DATASOURCE_ROOT_USERNAME
  valueFrom:
    secretKeyRef:
      name: {{ .Values.processengine.spring.datasource.root.databaseConnectivityRootSecretName }}
      key: {{ .Values.spring.datasource.databaseUsernameSecretValue }}
- name: SPRING_DATASOURCE_ROOT_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ .Values.processengine.spring.datasource.root.databaseConnectivityRootSecretName }}
      key: {{ .Values.spring.datasource.databasePasswordSecretValue }}
{{- else }}
- name: SPRING_DATASOURCE_ROOT_URL
  value: '{{ .Values.spring.datasource.processengine.root.url }}'
- name: SPRING_DATASOURCE_ROOT_USERNAME
  value: '{{ .Values.spring.datasource.processengine.root.username }}'
- name: SPRING_DATASOURCE_ROOT_PASSWORD
  value: '{{ .Values.spring.datasource.processengine.root.password }}'
{{- end }}
- name: SPRING_DATASOURCE_ROOT_DRIVERCLASSNAME
  value: '{{ .Values.spring.datasource.processengine.root.driverClassName }}'
- name: SPRING_JPA_ROOT_HIBERNATE_DDLAUTO
  value: '{{ .Values.processengine.spring.jpa.root.hibernate.ddlAuto }}'
{{- end -}}

#######################################################################################
##  Extra / Additional Environment Variables
##  Usage: include "shared.extraEnv" (dict "extraEnv" .Values.<service>.extraEnv)
##  Supports three forms per entry:
##    plain string   : { MY_VAR: "myvalue" }
##    secretKeyRef   : { MY_VAR: { valueFrom: { secretKeyRef: { name: s, key: k } } } }
##    configMapKeyRef: { MY_VAR: { valueFrom: { configMapKeyRef: { name: c, key: k } } } }
##  Or a YAML list of standard env entries (fallback).
#######################################################################################

{{- define "shared.extraEnv" -}}
{{- if .extraEnv }}
{{- if kindIs "map" .extraEnv }}
{{- range $key, $value := .extraEnv }}
{{- if kindIs "string" $value }}
- name: {{ $key }}
  value: {{ $value | quote }}
{{- else if $value.valueFrom.secretKeyRef }}
- name: {{ $key }}
  valueFrom:
    secretKeyRef:
      name: {{ $value.valueFrom.secretKeyRef.name }}
      key: {{ $value.valueFrom.secretKeyRef.key }}
{{- else if $value.valueFrom.configMapKeyRef }}
- name: {{ $key }}
  valueFrom:
    configMapKeyRef:
      name: {{ $value.valueFrom.configMapKeyRef.name }}
      key: {{ $value.valueFrom.configMapKeyRef.key }}
{{- end }}
{{- end }}
{{- else }}
{{- toYaml .extraEnv }}
{{- end }}
{{- end }}
{{- end -}}

#######################################################################################
##  Shared Security Environment Variables
#######################################################################################

{{/*
Shared security env vars (used by all three services).
*/}}
{{- define "shared.security.env" -}}
{{- if .Values.contentAutomation.security.enabled }}
- name: ASG_SECURITY_ENABLED
  value: '{{ .Values.contentAutomation.security.enabled }}'
- name: ASG_SECURITY_URL_PATTERNS
  value: '{{ .Values.contentAutomation.security.urlPatterns }}'
{{- if .Values.contentAutomation.security.csrf.enabled }}
- name: ASG_SECURITY_CSRF_ENABLED
  value: '{{ .Values.contentAutomation.security.csrf.enabled }}'
{{- end }}
{{- end }}
{{- if .Values.contentAutomation.security.basicauth.inbound }}
- name: ASG_SECURITY_BASICAUTH_INBOUND
  value: '{{ .Values.contentAutomation.security.basicauth.inbound }}'
- name: ASG_SECURITY_BASICAUTH_USERS_0_USERNAME
  value: '{{ .Values.contentAutomation.security.basicauth.username }}'
- name: ASG_SECURITY_BASICAUTH_USERS_0_PASSWORD
  value: '{{ .Values.contentAutomation.security.basicauth.password }}'
- name: ASG_SECURITY_BASICAUTH_USERS_0_GROUPS
  value: '{{ .Values.contentAutomation.security.basicauth.groups }}'
{{- end }}
{{- if .Values.contentAutomation.security.appServer.enabled }}
- name: ASG_SECURITY_APPSERVER_ENABLED
  value: '{{ .Values.contentAutomation.security.appServer.enabled }}'
- name: ASG_SECURITY_APPSERVER_TYPE
  value: '{{ .Values.contentAutomation.security.appServer.type }}'
- name: ASG_SECURITY_APPSERVER_ATTRIBUTES_USERNAME
  value: '{{ .Values.contentAutomation.security.appServer.attributes.userName }}'
- name: ASG_SECURITY_APPSERVER_ATTRIBUTES_GROUPNAMES
  value: '{{ .Values.contentAutomation.security.appServer.attributes.groupNames }}'
- name: ASG_SECURITY_APPSERVER_ATTRIBUTES_GROUPSEPARATOR
  value: '{{ .Values.contentAutomation.security.appServer.attributes.groupSeparator }}'
{{- end }}
{{- if .Values.contentAutomation.security.jwt.enabled }}
- name: ASG_SECURITY_JWT_ENABLED
  value: '{{ .Values.contentAutomation.security.jwt.enabled }}'
- name: ASG_SECURITY_JWT_SERVICETOKENSETTINGS_INTERNALCONFIG_PRIVATEKEY
  value: '{{ .Values.contentAutomation.security.jwt.serviceTokenSettings.internalConfig.privateKey }}'
- name: ASG_SECURITY_JWT_SERVICETOKENSETTINGS_INTERNALCONFIG_PUBLICKEY
  value: '{{ .Values.contentAutomation.security.jwt.serviceTokenSettings.internalConfig.publicKey }}'
- name: ASG_SECURITY_JWT_SERVICETOKENSETTINGS_INTERNALCONFIG_EXPIRESECONDS
  value: '{{ .Values.contentAutomation.security.jwt.serviceTokenSettings.internalConfig.expireSeconds }}'
{{- end }}
{{- if .Values.contentAutomation.security.openidConnectTwo.enabled }}
- name: ASG_SECURITY_OPENIDCONNECTTWO_ENABLED
  value: '{{ .Values.contentAutomation.security.openidConnectTwo.enabled }}'
- name: ASG_SECURITY_OPENIDCONNECTTWO_OUTBOUND
  value: '{{ .Values.contentAutomation.security.openidConnectTwo.outbound }}'
- name: ASG_SECURITY_OPENIDCONNECTTWO_VALIDATE
  value: '{{ .Values.contentAutomation.security.openidConnectTwo.validate }}'
- name: ASG_SECURITY_OPENIDCONNECTTWO_IAMGROUPS
  value: '{{ .Values.contentAutomation.security.openidConnectTwo.iamGroups }}'
{{- if hasKey .Values.contentAutomation.security.openidConnectTwo "jwtHeader" }}
- name: ASG_SECURITY_OPENIDCONNECTTWO_JWTHEADER
  value: '{{ .Values.contentAutomation.security.openidConnectTwo.jwtHeader }}'
{{- end }}
{{- if hasKey .Values.contentAutomation.security.openidConnectTwo "whitelistIssuers" }}
{{- range $i, $value := .Values.contentAutomation.security.openidConnectTwo.whitelistIssuers }}
- name: ASG_SECURITY_OPENIDCONNECTTWO_WHITELISTISSUERS_{{ $i }}
  value: {{ $value | quote }}
{{- end }}
{{- end }}
- name: ASG_SECURITY_OPENIDCONNECTTWO_MAPPING_USERNAME
  value: '{{ .Values.contentAutomation.security.openidConnectTwo.mapping.username }}'
- name: ASG_SECURITY_OPENIDCONNECTTWO_MAPPING_GROUPS
  value: '{{ .Values.contentAutomation.security.openidConnectTwo.mapping.groups }}'
- name: ASG_SECURITY_OPENIDCONNECTTWO_CLIENT_JWKURL
  value: '{{ .Values.contentAutomation.security.openidConnectTwo.client.jwkUrl }}'
- name: ASG_SECURITY_OPENIDCONNECTTWO_SERVICETOKENSETTINGS_INTERNALCONFIG_URLPATTERNS
  value: '{{ .Values.contentAutomation.security.openidConnectTwo.serviceTokenSettings.internalConfig.urlPatterns }}'
- name: ASG_SECURITY_OPENIDCONNECTTWO_SERVICETOKENSETTINGS_INTERNALCONFIG_PRIVATEKEY
  value: '{{ .Values.contentAutomation.security.openidConnectTwo.serviceTokenSettings.internalConfig.privateKey }}'
- name: ASG_SECURITY_OPENIDCONNECTTWO_SERVICETOKENSETTINGS_INTERNALCONFIG_PUBLICKEY
  value: '{{ .Values.contentAutomation.security.openidConnectTwo.serviceTokenSettings.internalConfig.publicKey }}'
{{- end }}
{{- if .Values.contentAutomation.security.iam.ldap.enabled }}
- name: ASG_SECURITY_IAM_LDAP_ENABLED
  value: '{{ .Values.contentAutomation.security.iam.ldap.enabled }}'
- name: ASG_SECURITY_IAM_LDAP_SERVER
  value: '{{ .Values.contentAutomation.security.iam.ldap.server }}'
- name: ASG_SECURITY_IAM_LDAP_PORT
  value: '{{ .Values.contentAutomation.security.iam.ldap.port }}'
- name: ASG_SECURITY_IAM_LDAP_USER
  value: '{{ .Values.contentAutomation.security.iam.ldap.user }}'
{{- if .Values.contentAutomation.security.iam.ldap.ldapSecretName }}
- name: ASG_SECURITY_IAM_LDAP_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ .Values.contentAutomation.security.iam.ldap.ldapSecretName }}
      key: {{ .Values.contentAutomation.security.iam.ldap.ldapPasswordSecretValue }}
{{- else }}
- name: ASG_SECURITY_IAM_LDAP_PASSWORD
  value: '{{ .Values.contentAutomation.security.iam.ldap.password }}'
{{- end }}
- name: ASG_SECURITY_IAM_LDAP_GROUPDN
  value: '{{ .Values.contentAutomation.security.iam.ldap.groupDN }}'
- name: ASG_SECURITY_IAM_LDAP_USERDN
  value: '{{ .Values.contentAutomation.security.iam.ldap.userDN }}'
- name: ASG_SECURITY_IAM_LDAP_USERATTRIBUTES
  value: '{{ .Values.contentAutomation.security.iam.ldap.userAttributes }}'
- name: ASG_SECURITY_IAM_LDAP_SEARCHTYPE
  value: '{{ .Values.contentAutomation.security.iam.ldap.searchType }}'
{{- end }}
{{- end -}}

#######################################################################################
##  Shared Logging Environment Variables
##  Merges .Values.contentAutomation.logging (common) with per-service logging overrides.
##  Service-specific values take precedence over common values.
##  Usage:
##    include "shared.logging.env" (dict "Values" .Values "serviceLogging" .Values.SERVICENAME.logging)
#######################################################################################
{{- define "shared.logging.env" -}}
{{- $common := .Values.contentAutomation.logging  | default dict }}
{{- $svc    := .serviceLogging  | default dict }}
{{- $cLvl   := $common.level    | default dict }}
{{- $sLvl   := $svc.level       | default dict }}
{{- $cPat   := $common.pattern  | default dict }}
{{- $sPat   := $svc.pattern     | default dict }}
{{- $cFile  := $common.file     | default dict }}
{{- $sFile  := $svc.file        | default dict }}

{{/* ── pattern ── */}}
- name: LOGGING_PATTERN_CONSOLE
  value: '{{ coalesce (index $sPat "console") (index $cPat "console") "" }}'
- name: LOGGING_PATTERN_FILE
  value: '{{ coalesce (index $sPat "file") (index $cPat "file") "" }}'

{{/* ── file ── */}}
- name: LOGGING_FILE_PATH
  value: '{{ coalesce (index $sFile "path") (index $cFile "path") "" }}'
- name: LOGGING_FILE_NAME
  value: '{{ coalesce (index $sFile "name") (index $cFile "name") "" }}'

{{/* ── root level ── */}}
- name: LOGGING_LEVEL_ROOT
  value: '{{ coalesce (index $sLvl "root") (index $cLvl "root") "INFO" }}'

{{/* ── com.asg.services (flat key from common, service can override) ── */}}
- name: LOGGING_LEVEL_COM_ASG_SERVICES
  value: '{{ coalesce (index $sLvl "com.asg.services") (index $cLvl "com.asg.services") "ERROR" }}'

{{/* ── org.* levels: read from common first, service can override ── */}}
- name: LOGGING_LEVEL_ORG_HIBERNATE
  value: '{{ coalesce (index $sLvl "org.hibernate") (index $cLvl "org.hibernate") "INFO" }}'
- name: LOGGING_LEVEL_ORG_FLYWAYDB
  value: '{{ coalesce (index $sLvl "org.flywaydb") (index $cLvl "org.flywaydb") "INFO" }}'
- name: LOGGING_LEVEL_ORG_SPRINGFRAMEWORK
  value: '{{ coalesce (index $sLvl "org.springframework") (index $cLvl "org.springframework") "INFO" }}'
- name: LOGGING_LEVEL_ORG_GLASSFISH_JERSEY
  value: '{{ coalesce (index $sLvl "org.glassfish.jersey") (index $cLvl "org.glassfish.jersey") "INFO" }}'
- name: LOGGING_LEVEL_ORG_REFLECTIONS
  value: '{{ coalesce (index $sLvl "org.reflections") (index $cLvl "org.reflections") "ERROR" }}'

{{/* ── service-specific flat keys (only emitted when defined in service logging) ── */}}
{{- if (index $sLvl "com.asg.services.studio") }}
- name: LOGGING_LEVEL_COM_ASG_SERVICES_STUDIO
  value: '{{ index $sLvl "com.asg.services.studio" }}'
{{- end }}
{{- if (index $sLvl "com.asg.services.prs") }}
- name: LOGGING_LEVEL_COM_ASG_SERVICES_PRS
  value: '{{ index $sLvl "com.asg.services.prs" }}'
{{- end }}
{{- if (index $sLvl "com.asg.services.processengine") }}
- name: LOGGING_LEVEL_COM_ASG_SERVICES_PROCESSENGINE
  value: '{{ index $sLvl "com.asg.services.processengine" }}'
{{- end }}
{{- if (index $sLvl "com.asg.services.policies") }}
- name: LOGGING_LEVEL_COM_ASG_SERVICES_POLICIES
  value: '{{ index $sLvl "com.asg.services.policies" }}'
{{- end }}
{{- if (index $sLvl "com.asg.services.datasource") }}
- name: LOGGING_LEVEL_COM_ASG_SERVICES_DATASOURCE
  value: '{{ index $sLvl "com.asg.services.datasource" }}'
{{- end }}
{{- if (index $sLvl "com.asg.services.server") }}
- name: LOGGING_LEVEL_COM_ASG_SERVICES_SERVER
  value: '{{ index $sLvl "com.asg.services.server" }}'
{{- end }}
{{- end -}}

#######################################################################################
##  Full Container Templates (shared between combined and separate modes)
##  Each template renders a single container entry (list item starting with "- name:").
##  Usage in combined mode   : include "studio.container" (dict "Values" .Values "Chart" .Chart "Release" .Release "volumeName" "studio-log-data")
##  Usage in separate mode   : include "studio.container" (dict "Values" .Values "Chart" .Chart "Release" .Release "volumeName" "log-data")
#######################################################################################

{{/*
Studio full container spec
*/}}
{{- define "studio.container" -}}
- name: studio
  {{- if .Values.contentAutomation.image.studio.registry }}
  image: "{{ .Values.contentAutomation.image.studio.registry }}/{{ .Values.contentAutomation.image.studio.name }}:{{ .Values.contentAutomation.image.studio.tag | default .Chart.AppVersion }}"
  {{- else }}
  image: "{{ .Values.contentAutomation.image.studio.name }}:{{ .Values.contentAutomation.image.studio.tag | default .Chart.AppVersion }}"
  {{- end }}
  imagePullPolicy: {{ .Values.contentAutomation.image.studio.pullPolicy }}
  volumeMounts:
    {{- if .Values.studio.persistence.enabled }}
    - name: {{ .volumeName }}
      mountPath: /home/asg/asg/studio/logs
    {{- end }}
    {{- if .Values.studio.additionalVolumeMounts }}
    {{- toYaml .Values.studio.additionalVolumeMounts | nindent 4 }}
    {{- end }}
  ports:
    - name: http
      containerPort: 8082
      protocol: TCP
    - name: debug
      containerPort: 5005
      protocol: TCP
  {{- if .Values.studio.livenessProbe.enabled }}
  livenessProbe:
    httpGet:
      path: {{ .Values.studio.livenessProbe.httpGet.path }}
      port: {{ .Values.studio.livenessProbe.httpGet.port }}
    initialDelaySeconds: {{ .Values.studio.livenessProbe.initialDelaySeconds }}
    periodSeconds: {{ .Values.studio.livenessProbe.periodSeconds }}
    timeoutSeconds: {{ .Values.studio.livenessProbe.timeoutSeconds }}
  {{- end }}
  {{- if .Values.studio.readinessProbe.enabled }}
  readinessProbe:
    httpGet:
      path: {{ .Values.studio.readinessProbe.httpGet.path }}
      port: {{ .Values.studio.readinessProbe.httpGet.port }}
    initialDelaySeconds: {{ .Values.studio.readinessProbe.initialDelaySeconds }}
    periodSeconds: {{ .Values.studio.readinessProbe.periodSeconds }}
    timeoutSeconds: {{ .Values.studio.readinessProbe.timeoutSeconds }}
  {{- end }}
  securityContext:
    allowPrivilegeEscalation: {{ .Values.studio.securityContext.allowPrivilegeEscalation }}
    capabilities:
      drop:
        {{- toYaml .Values.studio.securityContext.capabilities.drop | nindent 8 }}
    seccompProfile:
      type: {{ .Values.studio.securityContext.seccompProfile.type }}
  env:
  {{- include "studio.database.env" . | nindent 2 }}
  - name: PORTS_NAME
    value: '{{ .Values.studio.ports.name }}'
  - name: PORTS_CONTAINERPORT
    value: '{{ .Values.studio.ports.containerPort }}'
  - name: PORTS_TARGETPORT
    value: '{{ .Values.studio.ports.targetPort }}'
  - name: PORTS_PROTOCOL
    value: '{{ .Values.studio.ports.protocol }}'
  - name: SERVLET_MULTIPART_ENABLED
    value: '{{ .Values.contentAutomation.servlet.multipart.enabled }}'
  - name: SPRING_SERVLET_MULTIPART_ENABLED
    value: '{{ .Values.contentAutomation.servlet.multipart.enabled }}'
  - name: SPRING_SERVLET_MULTIPART_MAX_FILE_SIZE
    value: '{{ index .Values.contentAutomation.servlet.multipart "max-file-size" }}'
  - name: SPRING_SERVLET_MULTIPART_MAX_REQUEST_SIZE
    value: '{{ index .Values.contentAutomation.servlet.multipart "max-request-size" }}'
  - name: JAVA_OPTS
    value: "-agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5005"
  {{- if hasKey .Values.contentAutomation.cloud.discovery.client.simple.instances.authorization "uri" }}
  - name: SPRING_CLOUD_DISCOVERY_CLIENT_SIMPLE_INSTANCES_AUTHORIZATION_0_URI
    value: '{{ .Values.contentAutomation.cloud.discovery.client.simple.instances.authorization.uri }}'
  {{- if hasKey .Values.contentAutomation.cloud.discovery.client.simple.instances.authorization.metadata "context" }}
  - name: SPRING_CLOUD_DISCOVERY_CLIENT_SIMPLE_INSTANCES_AUTHORIZATION_0_METADATA_CONTEXT
    value: '{{ .Values.contentAutomation.cloud.discovery.client.simple.instances.authorization.metadata.context }}'
  {{- end }}
  {{- end }}
  - name: SERVER_PORT
    value: '{{ .Values.studio.server.port }}'
  {{- if .Values.studio.importCustomCertificate.enabled }}
  - name: SERVER_SSL_TRUST_STORE
    value: '/home/asg/truststore.jks'
  - name: SERVER_SSL_TRUST_STORE_PASSWORD
    value: 'changeit'
  - name: JAVA_OPTS
    value: '-Djavax.net.ssl.trustStore=/home/asg/truststore.jks -Djavax.net.ssl.trustStorePassword=changeit'
  {{- end }}
  - name: STUDIO_AUTHORIZATION_ENABLED
    value: '{{ .Values.studio.authorization.enabled }}'
  - name: CONTENTAUTOMATION_DEPLOYMENT_TYPE
    value: '{{ .Values.deploymentMode }}'
  - name: APPMANAGER_PORT
    value: '{{ .Values.appmanager.server.port }}'
  - name: PROCESSENGINE_PORT
    value: '{{ .Values.processengine.server.port }}'
  - name: STUDIO_SERVICE_LOCATION
    value: '{{ .Values.studio.service.location }}'
  - name: STUDIO_SERVICE_WORKSPACENAME
    value: '{{ .Values.studio.service.workspaceName }}'
  - name: STUDIO_SERVICE_ANGULARWORKSPACE
    value: '{{ .Values.studio.service.angularWorkspace }}'
  - name: STUDIO_SERVICE_ENCRYPTIONKEY
    value: '{{ .Values.studio.service.encryptionKey }}'
  - name: STUDIO_SERVICE_AISERVICEURL
    value: '{{ .Values.studio.service.aiServiceUrl }}'
  - name: STUDIO_SERVICE_VALIDPROJECTFOLDERS
    value: '{{ .Values.studio.service.validProjectFolders }}'
  - name: STUDIO_SERVICE_SYNCTREEEXCLUSEFOLDERS
    value: '{{ .Values.studio.service.syncTreeExcludeFolders }}'
  - name: STUDIO_SERVICE_OPENPROJECTEXCLUDEFOLDER
    value: '{{ .Values.studio.service.openProjectExcludeFolder }}'
  - name: STUDIO_SERVICE_SCMIGNOREFILENAME
    value: '{{ .Values.studio.service.scmIgnoreFileName }}'
  {{- if ne .Values.deploymentMode "combined" }}
  - name: STUDIO_SERVICE_PROCESSENGINEURL
    value: '{{ .Values.contentAutomation.processEngineUrl }}'
  {{- end }}
  - name: STUDIO_SERVICE_MOBIUSRESOURCESURL
    value: '{{ .Values.contentAutomation.mobiusResourcesUrl }}'
  - name: STUDIO_SERVICE_ENABLE-AI
    value: '{{ .Values.studio.service.EnableAI }}'
  - name: STUDIO_SERVICE_PROJECTSMIGRATIONPATH
    value: '{{ .Values.studio.service.projectsMigrationPath }}'
  - name: STUDIO_SERVICE_DSPOOLSIZE
    value: '{{ .Values.studio.service.dsPoolSize }}'
  - name: STUDIO_SERVICE_RUNNINGPROPERTIES_MODE
    value: '{{ .Values.studio.service.runningProperties.mode }}'
  - name: STUDIO_SERVICE_RUNNINGPROPERTIES_AUTHORIZATION-ENABLED
    value: '{{ .Values.studio.service.runningProperties.authorizationEnabled }}'
  - name: STUDIO_SERVICE_RUNNINGPROPERTIES_MODE_AUTHORIZED_PERMISSIONS
    value: '{{ .Values.studio.service.runningProperties.authorized_permissions }}'
  - name: STUDIO_SERVICE_RUNNINGPROPERTIES_MODE_AUTHORIZED_SCOPES
    value: '{{ .Values.studio.service.runningProperties.authorized_scopes }}'
  - name: STUDIO_SERVICE_RUNNINGPROPERTIES_MODE_HTTPTIMEOUT
    value: '{{ .Values.studio.service.runningProperties.httptimeout }}'
  - name: STUDIO_SERVICE_NPMMODULES_NEW_0_NAME
    value: 'caniuse-lite'
  - name: STUDIO_SERVICE_NPMMODULES_NEW_0_VERSION
    value: 'file:../../../@updated_modules/caniuse-lite'
  - name: STUDIO_SERVICE_NPMMODULES_NEW_1_NAME
    value: 'jexcel'
  - name: STUDIO_SERVICE_NPMMODULES_NEW_1_VERSION
    value: '4.6.1'
  {{- include "shared.security.env" . | nindent 2 }}
  {{- include "shared.extraEnv" (dict "extraEnv" .Values.studio.extraEnv) | nindent 2 }}
  {{- if .Values.studio.authorization.enabled }}
  - name: ASG_AUTHORIZATION_ENABLED
    value: '{{ .Values.studio.authorization.enabled }}'
  {{- end }}
  {{- include "shared.logging.env" (dict "Values" .Values "serviceLogging" .Values.studio.logging) | nindent 2 }}
  resources:
    {{- toYaml .Values.studio.resources | nindent 4 }}
{{- end -}}

{{/*
AppManager full container spec
*/}}
{{- define "appmanager.container" -}}
- name: appmanager
  {{- if .Values.contentAutomation.image.appmanager.registry }}
  image: "{{ .Values.contentAutomation.image.appmanager.registry }}/{{ .Values.contentAutomation.image.appmanager.name }}:{{ .Values.contentAutomation.image.appmanager.tag | default .Chart.AppVersion }}"
  {{- else }}
  image: "{{ .Values.contentAutomation.image.appmanager.name }}:{{ .Values.contentAutomation.image.appmanager.tag | default .Chart.AppVersion }}"
  {{- end }}
  imagePullPolicy: {{ .Values.contentAutomation.image.appmanager.pullPolicy }}
  volumeMounts:
    {{- if .Values.appmanager.persistence.enabled }}
    - name: {{ .volumeName }}
      mountPath: /home/asg/asg/appmanager/logs
    {{- end }}
    {{- if .Values.appmanager.additionalVolumeMounts }}
    {{- toYaml .Values.appmanager.additionalVolumeMounts | nindent 4 }}
    {{- end }}
  ports:
    - name: http
      containerPort: 8521
      protocol: TCP
    - name: debug
      containerPort: 5006
      protocol: TCP
  {{- if .Values.appmanager.livenessProbe.enabled }}
  livenessProbe:
    httpGet:
      path: {{ .Values.appmanager.livenessProbe.httpGet.path }}
      port: {{ .Values.appmanager.livenessProbe.httpGet.port }}
    initialDelaySeconds: {{ .Values.appmanager.livenessProbe.initialDelaySeconds }}
    periodSeconds: {{ .Values.appmanager.livenessProbe.periodSeconds }}
    timeoutSeconds: {{ .Values.appmanager.livenessProbe.timeoutSeconds }}
  {{- end }}
  {{- if .Values.appmanager.readinessProbe.enabled }}
  readinessProbe:
    httpGet:
      path: {{ .Values.appmanager.readinessProbe.httpGet.path }}
      port: {{ .Values.appmanager.readinessProbe.httpGet.port }}
    initialDelaySeconds: {{ .Values.appmanager.readinessProbe.initialDelaySeconds }}
    periodSeconds: {{ .Values.appmanager.readinessProbe.periodSeconds }}
    timeoutSeconds: {{ .Values.appmanager.readinessProbe.timeoutSeconds }}
  {{- end }}
  securityContext:
    allowPrivilegeEscalation: {{ .Values.appmanager.securityContext.allowPrivilegeEscalation }}
    capabilities:
      drop:
        {{- toYaml .Values.appmanager.securityContext.capabilities.drop | nindent 8 }}
    seccompProfile:
      type: {{ .Values.appmanager.securityContext.seccompProfile.type }}
  env:
  {{- include "appmanager.database.env" . | nindent 2 }}
  {{- $authorization := .Values.contentAutomation.cloud.discovery.client.simple.instances.authorization }}
  {{- if and $authorization (hasKey $authorization "uri") }}
  - name: SPRING_CLOUD_DISCOVERY_CLIENT_SIMPLE_INSTANCES_AUTHORIZATION_0_URI
    value: "{{ $authorization.uri }}"
  {{- end }}
  {{- if .Values.appmanager.importCustomCertificate.enabled }}
  - name: SERVER_SSL_TRUST_STORE
    value: '/home/asg/truststore.jks'
  - name: SERVER_SSL_TRUST_STORE_PASSWORD
    value: 'changeit'
  - name: JAVA_OPTS
    value: '-Djavax.net.ssl.trustStore=/home/asg/truststore.jks -Djavax.net.ssl.trustStorePassword=changeit'
  {{- end }}
  - name: PORTS_NAME
    value: '{{ .Values.appmanager.ports.name }}'
  - name: SPRING_SERVLET_MULTIPART_ENABLED
    value: '{{ .Values.contentAutomation.servlet.multipart.enabled }}'
  - name: SPRING_SERVLET_MULTIPART_MAX_FILE_SIZE
    value: '{{ index .Values.contentAutomation.servlet.multipart "max-file-size" }}'
  - name: SPRING_SERVLET_MULTIPART_MAX_REQUEST_SIZE
    value: '{{ index .Values.contentAutomation.servlet.multipart "max-request-size" }}'
  - name: JAVA_OPTS
    value: "-agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5006"
  - name: SERVER_PORT
    value: '{{ .Values.appmanager.server.port }}'
  - name: CONTENTAUTOMATION_DEPLOYMENT_TYPE
    value: '{{ .Values.deploymentMode }}'
  - name: STUDIO_PORT
    value: '{{ .Values.studio.server.port }}'
  - name: PROCESSENGINE_PORT
    value: '{{ .Values.processengine.server.port }}'
  - name: PORTS_CONTAINERPORT
    value: '{{ .Values.appmanager.ports.containerPort }}'
  - name: PORTS_TARGETPORT
    value: '{{ .Values.appmanager.ports.targetPort }}'
  - name: PORTS_PROTOCOL
    value: '{{ .Values.appmanager.ports.protocol }}'
  - name: PRS_SERVICE_CLIENT_LOCATION
    value: '{{ .Values.appmanager.prs.service.client.location }}'
  {{- if ne .Values.deploymentMode "combined" }}
  - name: PRS_SERVICE_PROCESSENGINEURL
    value: '{{ .Values.contentAutomation.processEngineUrl }}'
  {{- end }}
  - name: PRS_SERVICE_MOBIUSVIEWURL
    value: '{{ .Values.contentAutomation.mobiusViewUrl }}'
  {{- include "shared.security.env" . | nindent 2 }}
  {{- include "shared.extraEnv" (dict "extraEnv" .Values.appmanager.extraEnv) | nindent 2 }}
  {{- if .Values.appmanager.asg.authorization.enabled }}
  - name: ASG_AUTHORIZATION_ENABLED
    value: '{{ .Values.appmanager.asg.authorization.enabled }}'
  - name: ASG_AUTHORIZATION_USERNAME
    value: '{{ .Values.appmanager.asg.authorization.username }}'
  - name: ASG_AUTHORIZATION_TENANT
    value: '{{ .Values.appmanager.asg.authorization.tenant }}'
  - name: ASG_AUTHORIZATION_GROUP
    value: '{{ .Values.appmanager.asg.authorization.group }}'
  {{- end }}
  {{- include "shared.logging.env" (dict "Values" .Values "serviceLogging" .Values.appmanager.logging) | nindent 2 }}
  resources:
    {{- toYaml .Values.appmanager.resources | nindent 4 }}
{{- end -}}

{{/*
ProcessEngine full container spec
*/}}
{{- define "processengine.container" -}}
- name: processengine
  {{- if .Values.contentAutomation.image.processengine.registry }}
  image: "{{ .Values.contentAutomation.image.processengine.registry }}/{{ .Values.contentAutomation.image.processengine.name }}:{{ .Values.contentAutomation.image.processengine.tag | default .Chart.AppVersion }}"
  {{- else }}
  image: "{{ .Values.contentAutomation.image.processengine.name }}:{{ .Values.contentAutomation.image.processengine.tag | default .Chart.AppVersion }}"
  {{- end }}
  imagePullPolicy: {{ .Values.contentAutomation.image.processengine.pullPolicy }}
  volumeMounts:
    {{- if .Values.processengine.additionalVolumeMounts }}
    {{- toYaml .Values.processengine.additionalVolumeMounts | nindent 4 }}
    {{- end }}
  ports:
    - name: http
      containerPort: 8522
      protocol: TCP
    - name: debug
      containerPort: 5007
      protocol: TCP
  {{- if .Values.processengine.livenessProbe.enabled }}
  livenessProbe:
    httpGet:
      path: {{ .Values.processengine.livenessProbe.httpGet.path }}
      port: {{ .Values.processengine.livenessProbe.httpGet.port }}
    initialDelaySeconds: {{ .Values.processengine.livenessProbe.initialDelaySeconds }}
    periodSeconds: {{ .Values.processengine.livenessProbe.periodSeconds }}
    timeoutSeconds: {{ .Values.processengine.livenessProbe.timeoutSeconds }}
  {{- end }}
  {{- if .Values.processengine.readinessProbe.enabled }}
  readinessProbe:
    httpGet:
      path: {{ .Values.processengine.readinessProbe.httpGet.path }}
      port: {{ .Values.processengine.readinessProbe.httpGet.port }}
    initialDelaySeconds: {{ .Values.processengine.readinessProbe.initialDelaySeconds }}
    periodSeconds: {{ .Values.processengine.readinessProbe.periodSeconds }}
    timeoutSeconds: {{ .Values.processengine.readinessProbe.timeoutSeconds }}
  {{- end }}
  securityContext:
    allowPrivilegeEscalation: {{ .Values.processengine.securityContext.allowPrivilegeEscalation }}
    capabilities:
      drop:
        {{- toYaml .Values.processengine.securityContext.capabilities.drop | nindent 8 }}
    seccompProfile:
      type: {{ .Values.processengine.securityContext.seccompProfile.type }}
  env:
  {{- if hasKey .Values.contentAutomation.cloud.discovery.client.simple.instances.authorization "uri" }}
  - name: SPRING_CLOUD_DISCOVERY_CLIENT_SIMPLE_INSTANCES_AUTHORIZATION_0_URI
    value: '{{ .Values.contentAutomation.cloud.discovery.client.simple.instances.authorization.uri }}'
  {{- if hasKey .Values.contentAutomation.cloud.discovery.client.simple.instances.authorization "metadata" }}
  {{- if hasKey .Values.contentAutomation.cloud.discovery.client.simple.instances.authorization.metadata "context" }}
  - name: SPRING_CLOUD_DISCOVERY_CLIENT_SIMPLE_INSTANCES_AUTHORIZATION_0_METADATA_CONTEXT
    value: '{{ .Values.contentAutomation.cloud.discovery.client.simple.instances.authorization.metadata.context }}'
  {{- end }}
  {{- end }}
  {{- end }}
  {{- include "processengine.database.env" . | nindent 2 }}
  {{- /* ── FlowableHikari pool ─────────────────────────────────────────────────────── */}}
  {{- /* Source of truth: spring.datasource.processengine.flowable.hikari in values.yaml */}}
  - name: SPRING_DATASOURCE_PROCESSENGINE_FLOWABLE_HIKARI_POOLNAME
    value: '{{ .Values.spring.datasource.processengine.flowable.hikari.poolName }}'
  - name: SPRING_DATASOURCE_PROCESSENGINE_FLOWABLE_HIKARI_CONNECTIONTIMEOUT
    value: '{{ .Values.spring.datasource.processengine.flowable.hikari.connectionTimeout }}'
  - name: SPRING_DATASOURCE_PROCESSENGINE_FLOWABLE_HIKARI_MINIMUMIDLE
    value: '{{ .Values.spring.datasource.processengine.flowable.hikari.minimumIdle }}'
  - name: SPRING_DATASOURCE_PROCESSENGINE_FLOWABLE_HIKARI_MAXIMUMPOOLSIZE
    value: '{{ .Values.spring.datasource.processengine.flowable.hikari.maximumPoolSize }}'
  - name: SPRING_DATASOURCE_PROCESSENGINE_FLOWABLE_HIKARI_IDLETIMEOUT
    value: '{{ .Values.spring.datasource.processengine.flowable.hikari.idleTimeout }}'
  - name: SPRING_DATASOURCE_PROCESSENGINE_FLOWABLE_HIKARI_MAXLIFETIME
    value: '{{ .Values.spring.datasource.processengine.flowable.hikari.maxLifetime }}'
  - name: SPRING_DATASOURCE_PROCESSENGINE_FLOWABLE_HIKARI_AUTOCOMMIT
    value: '{{ .Values.spring.datasource.processengine.flowable.hikari.autoCommit }}'
  {{- /* ── RootHikari pool ──────────────────────────────────────────────────────────── */}}
  {{- /* Source of truth: spring.datasource.processengine.root.hikari in values.yaml */}}
  - name: SPRING_DATASOURCE_PROCESSENGINE_ROOT_HIKARI_POOLNAME
    value: '{{ .Values.spring.datasource.processengine.root.hikari.poolName }}'
  - name: SPRING_DATASOURCE_PROCESSENGINE_ROOT_HIKARI_CONNECTIONTIMEOUT
    value: '{{ .Values.spring.datasource.processengine.root.hikari.connectionTimeout }}'
  - name: SPRING_DATASOURCE_PROCESSENGINE_ROOT_HIKARI_MINIMUMIDLE
    value: '{{ .Values.spring.datasource.processengine.root.hikari.minimumIdle }}'
  - name: SPRING_DATASOURCE_PROCESSENGINE_ROOT_HIKARI_MAXIMUMPOOLSIZE
    value: '{{ .Values.spring.datasource.processengine.root.hikari.maximumPoolSize }}'
  - name: SPRING_DATASOURCE_PROCESSENGINE_ROOT_HIKARI_IDLETIMEOUT
    value: '{{ .Values.spring.datasource.processengine.root.hikari.idleTimeout }}'
  - name: SPRING_DATASOURCE_PROCESSENGINE_ROOT_HIKARI_MAXLIFETIME
    value: '{{ .Values.spring.datasource.processengine.root.hikari.maxLifetime }}'
  - name: SPRING_DATASOURCE_PROCESSENGINE_ROOT_HIKARI_AUTOCOMMIT
    value: '{{ .Values.spring.datasource.processengine.root.hikari.autoCommit }}'
  - name: SPRING_H2_CONSOLE_ENABLED
    value: '{{ .Values.processengine.spring.h2.console.enabled }}'
  - name: SERVER_PORT
    value: '{{ .Values.processengine.server.port }}'
  - name: JAVA_OPTS
    value: "-agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5007"
  - name: PORTS_NAME
    value: '{{ .Values.processengine.ports.name }}'
  - name: SPRING_SERVLET_MULTIPART_ENABLED
    value: '{{ .Values.contentAutomation.servlet.multipart.enabled }}'
  - name: SPRING_SERVLET_MULTIPART_MAX_FILE_SIZE
    value: '{{ index .Values.contentAutomation.servlet.multipart "max-file-size" }}'
  - name: SPRING_SERVLET_MULTIPART_MAX_REQUEST_SIZE
    value: '{{ index .Values.contentAutomation.servlet.multipart "max-request-size" }}'
  - name: PORTS_CONTAINERPORT
    value: '{{ .Values.processengine.ports.containerPort }}'
  - name: PORTS_TARGETPORT
    value: '{{ .Values.processengine.ports.targetPort }}'
  - name: PORTS_PROTOCOL
    value: '{{ .Values.processengine.ports.protocol }}'
  - name: FLYWAY_ENABLED
    value: '{{ .Values.processengine.flyway.enabled }}'
  - name: FLOWABLE_HTTP_CONNECTIONTIMEOUT
    value: '{{ .Values.processengine.flowable.http.connectionTimeout }}'
  - name: FLOWABLE_HTTP_CONNECTIONREQUESTTIMEOUT
    value: '{{ .Values.processengine.flowable.http.connectionRequestTimeout }}'
  - name: FLOWABLE_HTTP_SOCKETTIMEOUT
    value: '{{ .Values.processengine.flowable.http.socketTimeout }}'
  - name: FLOWABLE_HTTP_ENABLEHISTORYCLEANING
    value: '{{ .Values.processengine.flowable.enableHistoryCleaning }}'
  - name: FLOWABLE_HTTP_HISTORYCLEANINGCYCLE
    value: '{{ .Values.processengine.flowable.historyCleaningCycle }}'
  - name: FLOWABLE_HTTP_HISTORYCLEANINGAFTER
    value: '{{ .Values.processengine.flowable.historyCleaningAfter }}'
  - name: FLOWABLE_HTTP_HISTORYBATCHSIZE
    value: '{{ .Values.processengine.flowable.historyCleaningBatchSize }}'
  - name: FLOWABLE_MAIL_SERVER_HOST
    value: '{{ .Values.processengine.flowable.mail.server.host }}'
  - name: FLOWABLE_MAIL_SERVER_PORT
    value: '{{ .Values.processengine.flowable.mail.server.port }}'
  - name: FLOWABLE_MAIL_SERVER_USESSL
    value: '{{ .Values.processengine.flowable.mail.server.useSsl }}'
  - name: FLOWABLE_MAIL_SERVER_SSLPORT
    value: '{{ .Values.processengine.flowable.mail.server.sslPort }}'
  - name: FLOWABLE_MAIL_SERVER_DEFAULTFROM
    value: '{{ .Values.processengine.flowable.mail.server.defaultFrom }}'
  - name: FLOWABLE_MAIL_SERVER_USERNAME
    value: '{{ .Values.processengine.flowable.mail.server.username }}'
  {{- if .Values.processengine.flowable.mail.server.mailServerSecretName }}
  - name: FLOWABLE_MAIL_SERVER_PASSWORD
    valueFrom:
      secretKeyRef:
        name: {{ .Values.processengine.flowable.mail.server.mailServerSecretName }}
        key: {{ .Values.processengine.flowable.mail.server.mailServerPasswordSecretValue }}
  {{- else }}
  - name: FLOWABLE_MAIL_SERVER_PASSWORD
    value: '{{ .Values.processengine.flowable.mail.server.password }}'
  {{- end }}
  - name: PROCESSENGINE_AWSACCESSKEY
    value: '{{ .Values.processengine.awsAccessKey }}'
  - name: CONTENTAUTOMATION_DEPLOYMENT_TYPE
    value: '{{ .Values.deploymentMode }}'
  - name: APPMANAGER_PORT
    value: '{{ .Values.appmanager.server.port }}'
  - name: STUDIO_PORT
    value: '{{ .Values.studio.server.port }}'
  - name: PROCESSENGINE_AWSSECRETKEY
    value: '{{ .Values.processengine.awsSecretKey }}'
  - name: PROCESSENGINE_AWSREGION
    value: '{{ .Values.processengine.awsRegion }}'
  - name: PROCESSENGINE_AWSS3BUCKETINPUT
    value: '{{ .Values.processengine.awsS3BucketInput }}'
  - name: PROCESSENGINE_AWSS3BUCKETOUTPUT
    value: '{{ .Values.processengine.awsS3BucketOutput }}'
  - name: PROCESSENGINE_AWSSQSARN
    value: '{{ .Values.processengine.awsSqsArn }}'
  - name: PROCESSENGINE_AWSSQSROLE
    value: '{{ .Values.processengine.awsSqsRole }}'
  - name: PROCESSENGINE_AWSCOMPREHENDROLE
    value: '{{ .Values.processengine.awsComprehendRole }}'
  - name: PROCESSENGINE_AWSCLIENTRETRYDELAYINSEC
    value: '{{ .Values.processengine.awsClientRetryDelayInSec }}'
  - name: PROCESSENGINE_AWSCLIENTRETRYCOUNT
    value: '{{ .Values.processengine.awsClientRetryCount }}'
  - name: PROCESSENGINE_HTTP_MAX_TOTAL_CONNECTIONS
    value: '{{ .Values.processengine.httpMaxTotalConnections }}'
  - name: PROCESSENGINE_HTTP_DEFAULT_CONN_MAX_PER_ROUTE
    value: '{{ .Values.processengine.httpDefaultConnMaxPerRoute }}'
  - name: PROCESSENGINE_HTTPIDLECONNWAITTIMEBEFORECLOSEINSEC
    value: '{{ .Values.processengine.HttpIdelConnWaitTimeBeforeClassInSec }}'
  - name: PROCESSENGINE_HTTPCONNKEEPALIVETIMEINSEC
    value: '{{ .Values.processengine.HttpConnKeepAliveTimeInSec }}'
  - name: PROCESSENGINE_ASYNCEXECUTORMAXPOOLSIZE
    value: '{{ .Values.processengine.asyncExecutorMaxPoolSize }}'
  - name: PROCESSENGINE_ASYNCEXECUTORCOREPOOLSIZE
    value: '{{ .Values.processengine.asyncExecutorCorePoolSize }}'
  - name: PROCESSENGINE_ASYNCEXECUTORTHREADQUEUESIZE
    value: '{{ .Values.processengine.asyncExecutorThreadQueueSize }}'
  - name: PROCESSENGINE_MAILCONNECTTIMEOUT
    value: '{{ .Values.processengine.mailConnectTimeout }}'
  - name: PROCESSENGINE_MAILSOCKETTIMEOUT
    value: '{{ .Values.processengine.mailSocketTimeout }}'
  - name: PROCESSENGINE_FILESTORAGE_LOCATION
    value: '{{ .Values.processengine.filestorage.location }}'
  - name: PROCESSENGINE_FILESTORAGE_DELETIONSCHEDULE
    value: '{{ .Values.processengine.filestorage.deletionSchedule }}'
  {{- if ne .Values.deploymentMode "combined" }}
  - name: PROCESSENGINE_STUDIOSERVICEURL
    value: '{{ .Values.contentAutomation.studioServiceUrl }}'
  - name: PROCESSENGINE_CONTENTAUTOMATIONSERVICEURL
    value: '{{ .Values.contentAutomation.contentautomationServiceUrl }}'
  - name: PROCESSENGINE_AUTHORIZATIONSERVICEHOST
    value: '{{ .Values.contentAutomation.authorizationServiceHost }}'
  {{- end }}
  - name: PROCESSENGINE_MOBIUSRESOURCESURL
    value: '{{ .Values.contentAutomation.mobiusResourcesUrl }}'
  - name: PROCESSENGINE_MOBIUSCONNECTORVERSION
    value: '{{ .Values.processengine.mobiusConnectorVersion }}'
  - name: PROCESSENGINE_AI_MCP_SERVER_ENABLED
    value: '{{ .Values.processengine.ai.mcp.server.enabled }}'
  - name: PROCESSENGINE_AGENT_LLM_OPENAI_API_KEY
    value: '{{ .Values.processengine.agent.llm.openai.api_key }}'
  - name: PROCESSENGINE_AGENT_LLM_OPENAI_GENERATION_CONFIG_MODEL
    value: '{{ .Values.processengine.agent.llm.openai.generation_config.model }}'
  - name: PROCESSENGINE_AGENT_LLM_OPENAI_GENERATION_CONFIG_TEMPERATURE
    value: '{{ .Values.processengine.agent.llm.openai.generation_config.temperature }}'
  {{- range $index, $mcpserver := .Values.processengine.agent.mcpservers }}
  - name: PROCESSENGINE_AGENT_MCPSERVERS_{{ $index }}_NAME
    value: '{{ $mcpserver.name }}'
  - name: PROCESSENGINE_AGENT_MCPSERVERS_{{ $index }}_TRANSPORT
    value: '{{ $mcpserver.transport }}'
  - name: PROCESSENGINE_AGENT_MCPSERVERS_{{ $index }}_TIMEOUT
    value: '{{ $mcpserver.timeout }}'
  {{- if eq $mcpserver.transport "SSE" }}
  {{- if $mcpserver.sse }}
  - name: PROCESSENGINE_AGENT_MCPSERVERS_{{ $index }}_SSE_BASEURL
    value: '{{ $mcpserver.sse.baseUrl }}'
  - name: PROCESSENGINE_AGENT_MCPSERVERS_{{ $index }}_SSE_TOOLSPATH
    value: '{{ $mcpserver.sse.toolsPath }}'
  {{- if $mcpserver.sse.auth }}
  - name: PROCESSENGINE_AGENT_MCPSERVERS_{{ $index }}_SSE_AUTH_TYPE
    value: '{{ $mcpserver.sse.auth.type }}'
  - name: PROCESSENGINE_AGENT_MCPSERVERS_{{ $index }}_SSE_AUTH_TOKEN
    value: '{{ $mcpserver.sse.auth.token }}'
  {{- end }}
  {{- end }}
  {{- else if eq $mcpserver.transport "STDIO" }}
  {{- if $mcpserver.stdio }}
  - name: PROCESSENGINE_AGENT_MCPSERVERS_{{ $index }}_STDIO_COMMAND
    value: '{{ $mcpserver.stdio.command }}'
  {{- if $mcpserver.stdio.args }}
  - name: PROCESSENGINE_AGENT_MCPSERVERS_{{ $index }}_STDIO_ARGS
    value: '{{ join "," $mcpserver.stdio.args }}'
  {{- end }}
  {{- if $mcpserver.stdio.env }}
  - name: PROCESSENGINE_AGENT_MCPSERVERS_{{ $index }}_STDIO_ENV_LOG_LEVEL
    value: '{{ $mcpserver.stdio.env.LOG_LEVEL }}'
  {{- end }}
  {{- end }}
  {{- else if eq $mcpserver.transport "STREAMABLE_HTTP" }}
  {{- if $mcpserver.streamableHttp }}
  - name: PROCESSENGINE_AGENT_MCPSERVERS_{{ $index }}_STREAMABLEHTTP_BASEURL
    value: '{{ $mcpserver.streamableHttp.baseUrl }}'
  - name: PROCESSENGINE_AGENT_MCPSERVERS_{{ $index }}_STREAMABLEHTTP_TOOLSPATH
    value: '{{ $mcpserver.streamableHttp.toolsPath }}'
  {{- if $mcpserver.streamableHttp.auth }}
  - name: PROCESSENGINE_AGENT_MCPSERVERS_{{ $index }}_STREAMABLEHTTP_AUTH_TYPE
    value: '{{ $mcpserver.streamableHttp.auth.type }}'
  - name: PROCESSENGINE_AGENT_MCPSERVERS_{{ $index }}_STREAMABLEHTTP_AUTH_TOKEN
    value: '{{ $mcpserver.streamableHttp.auth.token }}'
  {{- end }}
  {{- end }}
  {{- end }}
  {{- end }}
  {{- include "shared.security.env" . | nindent 2 }}
  {{- include "shared.extraEnv" (dict "extraEnv" .Values.processengine.extraEnv) | nindent 2 }}
  {{- if .Values.processengine.asg.authorization.enabled }}
  - name: AUTHORIZATION_ENABLED
    value: '{{ .Values.processengine.asg.authorization.enabled }}'
  {{- end }}
  {{- include "shared.logging.env" (dict "Values" .Values "serviceLogging" .Values.processengine.logging) | nindent 2 }}
  resources:
    {{- toYaml .Values.processengine.resources | nindent 4 }}
{{- end -}}
