{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "mobiusview.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "mobiusview.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "mobiusview.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "mobiusview.labels" -}}
app.kubernetes.io/name: {{ include "mobiusview.name" . }}
helm.sh/chart: {{ include "mobiusview.chart" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}


{{- define "mobiusview.apmApiKeySecretName" -}}
{{- if .Values.master.elasticapm.apmApiKey }}
{{ include "mobiusview.fullname" . }}-apm-apikey
{{- else -}}
{{ .Values.master.elasticapm.apmApiKeySecretName }}
{{- end -}}
{{- end -}}

{{- define "mobiusview.apmApiKeySecretKey" -}}
{{- if .Values.master.elasticapm.apmApiKey }}
apmApiKey
{{- else -}}
{{ .Values.master.elasticapm.apmApiKeySecretKey }}
{{- end -}}
{{- end -}}

{{- define "mobiusview.apmSecretTokenName" -}}
{{- if .Values.master.elasticapm.apmSecretToken }}
{{ include "mobiusview.fullname" . }}-apm-secrettoken
{{- else -}}
{{ .Values.master.elasticapm.apmSecretName }}
{{- end -}}
{{- end -}}

{{- define "mobiusview.apmSecretTokenKey" -}}
{{- if .Values.master.elasticapm.apmSecretToken }}
apmSecretToken
{{- else -}}
{{ .Values.master.elasticapm.apmSecretKey }}
{{- end -}}
{{- end -}}

{{- define "mobiusview.splunkSecretName" -}}
{{- if .Values.master.mobiusViewDiagnostics.fluentBitLogging.splunk.splunkSecretToken }}
{{ include "mobiusview.fullname" . }}-splunk-secrettoken
{{- else -}}
{{ .Values.master.mobiusViewDiagnostics.fluentBitLogging.splunk.splunkSecretName }}
{{- end -}}
{{- end -}}

{{- define "mobiusview.splunkSecretKey" -}}
{{- if .Values.master.mobiusViewDiagnostics.fluentBitLogging.splunk.splunkSecretToken }}
splunkSecretToken
{{- else -}}
{{ .Values.master.mobiusViewDiagnostics.fluentBitLogging.splunk.splunkSecretKey }}
{{- end -}}
{{- end -}}

